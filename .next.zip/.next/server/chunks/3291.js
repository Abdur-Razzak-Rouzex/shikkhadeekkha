"use strict";
exports.id = 3291;
exports.ids = [3291];
exports.modules = {

/***/ 3291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const CourseSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: true
  },
  type: {
    type: String,
    default: 'course'
  },
  slug: {
    type: String,
    required: true,
    unique: true
  },
  category: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
    ref: 'Category',
    required: true
  },
  subCategory: {
    type: String
  },
  image: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  brand: {
    type: String,
    default: 'general'
  },
  countInStock: {
    type: Number,
    default: 0
  },
  languageMedium: {
    type: String,
    default: 'Bangla'
  },
  offerInPercentage: {
    type: Number,
    default: 0
  },
  rating: {
    type: Number,
    default: 0
  },
  numOfReviews: {
    type: Number,
    default: 0
  },
  description: {
    type: String,
    required: true
  },
  isFeatured: {
    type: Boolean,
    required: true,
    default: false
  },
  isOffered: {
    type: Boolean,
    required: true,
    default: false
  },
  docStatus: {
    type: Boolean,
    required: true,
    default: true
  }
}, {
  timestamps: true
});
const Course = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Course) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Course', CourseSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Course);

/***/ })

};
;