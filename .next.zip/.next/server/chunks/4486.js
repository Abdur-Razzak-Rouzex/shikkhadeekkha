"use strict";
exports.id = 4486;
exports.ids = [4486];
exports.modules = {

/***/ 4486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductItem)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4459);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);








function ProductItem({
  item,
  addToCartHandler
}) {
  const {
    0: offeredPrice,
    1: setOfferedPrice
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (item !== null && item !== void 0 && item.isOffered) {
      setOfferedPrice((0,_utils_helpers__WEBPACK_IMPORTED_MODULE_5__/* .calculateOfferPrice */ .$)(item === null || item === void 0 ? void 0 : item.price, item === null || item === void 0 ? void 0 : item.offerInPercentage));
    }
  }, [item]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Card, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__.default, {
      href: `/product/${item === null || item === void 0 ? void 0 : item.slug}`,
      passHref: true,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.CardActionArea, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.CardMedia, {
          component: "img",
          image: item === null || item === void 0 ? void 0 : item.image,
          title: item === null || item === void 0 ? void 0 : item.name
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.CardContent, {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
            container: true,
            spacing: 1,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
              item: true,
              xs: 12,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
                children: item === null || item === void 0 ? void 0 : item.name
              })
            }), item !== null && item !== void 0 && item.isOffered ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
                item: true,
                xs: 12,
                sx: {
                  display: 'flex',
                  justifyContent: 'space-between'
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("del", {
                  style: {
                    color: 'red'
                  },
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Chip, {
                    label: `${item === null || item === void 0 ? void 0 : item.price} ৳`,
                    size: "small",
                    color: "primary"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Chip, {
                  label: `${offeredPrice} ৳`,
                  size: "medium",
                  color: "secondary",
                  sx: {
                    marginLeft: 2
                  }
                })]
              })
            }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
              item: true,
              xs: 12,
              sx: {
                textAlign: 'end'
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Chip, {
                label: `${item === null || item === void 0 ? void 0 : item.price} ৳`,
                size: "medium",
                color: "secondary"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
              item: true,
              xs: 6,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_3___default()), {
                value: item === null || item === void 0 ? void 0 : item.rating,
                readOnly: true,
                precision: 0.25
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
              item: true,
              xs: 6,
              sx: {
                textAlign: 'end'
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
                size: "small",
                color: "primary",
                variant: "contained",
                onClick: () => addToCartHandler(item),
                children: (item === null || item === void 0 ? void 0 : item.type) === 'course' ? 'Enroll Now' : 'Add to cart'
              })
            })]
          })
        })]
      })
    })
  });
}

/***/ }),

/***/ 8054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ calculateOfferPrice)
/* harmony export */ });
function calculateOfferPrice(originalPrice, offerPercentage) {
  const newPrice = originalPrice - originalPrice * (offerPercentage / 100);
  return Math.ceil(newPrice);
}

/***/ })

};
;