"use strict";
(() => {
var exports = {};
exports.id = 9595;
exports.ids = [9595];
exports.modules = {

/***/ 8612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const NoDataFoundComponent = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
    container: true,
    sx: {
      justifyContent: 'center',
      marginTop: 5
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
      variant: "h1",
      component: "h1",
      children: "No data found"
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NoDataFoundComponent);

/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const whyChooseUsSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  smallImage: {
    type: String,
    required: true
  },
  largeImage: {
    type: String,
    required: false
  },
  title: {
    type: String,
    required: true
  },
  shortDescription: {
    type: String,
    required: true
  },
  isFlipBook: {
    type: Boolean,
    required: true
  },
  flipBookLink: {
    type: String,
    required: false
  },
  contentBody: {
    type: String,
    required: false
  }
}, {
  timestamps: true
});
const WhyChooseUs = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.WhyChooseUs) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('WhyChooseUs', whyChooseUsSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhyChooseUs);

/***/ }),

/***/ 8890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./components/Layout.js + 2 modules
var Layout = __webpack_require__(1783);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(6420);
// EXTERNAL MODULE: ./models/WhyChooseUs.js
var WhyChooseUs = __webpack_require__(3174);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8035);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: ./components/common/NoDataFoundComponent.js
var NoDataFoundComponent = __webpack_require__(8612);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/about-us/AboutUsDetailsComponent.js





const PREFIX = 'RecentActivitiesDetails';
const classes = {
  date: `${PREFIX}-date`,
  icon: `${PREFIX}-icon`
};
const StyledContainer = (0,styles_.styled)(material_.Container)(({
  theme
}) => ({
  [`& .${classes.date}`]: {
    display: 'flex',
    alignItems: 'center',
    color: theme.palette.primary.main
  },
  [`& .${classes.icon}`]: {
    color: '#ffff',
    padding: '2px',
    borderRadius: '3px',
    '&:not(:last-child)': {
      marginRight: '10px'
    }
  }
}));

const RecentActivitiesDetails = ({
  whyChooseUsData
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(StyledContainer, {
    maxWidth: 'lg',
    children: whyChooseUsData ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          component: "h1",
          variant: "h1",
          fontWeight: 'bold',
          sx: {
            textAlign: 'center'
          },
          children: whyChooseUsData === null || whyChooseUsData === void 0 ? void 0 : whyChooseUsData.title
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        my: 3,
        children: (whyChooseUsData === null || whyChooseUsData === void 0 ? void 0 : whyChooseUsData.largeImage) && /*#__PURE__*/jsx_runtime_.jsx(material_.CardMedia, {
          component: "img",
          height: "350",
          image: whyChooseUsData === null || whyChooseUsData === void 0 ? void 0 : whyChooseUsData.largeImage,
          alt: whyChooseUsData === null || whyChooseUsData === void 0 ? void 0 : whyChooseUsData.title,
          title: whyChooseUsData === null || whyChooseUsData === void 0 ? void 0 : whyChooseUsData.title
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "subtitle1",
          children: whyChooseUsData.contentBody
        })
      })]
    }) : /*#__PURE__*/jsx_runtime_.jsx(NoDataFoundComponent/* default */.Z, {})
  });
};

/* harmony default export */ const AboutUsDetailsComponent = (RecentActivitiesDetails);
;// CONCATENATED MODULE: ./pages/about-us/[id].js






function Home(props) {
  const {
    whyChooseUsData
  } = props;
  return /*#__PURE__*/jsx_runtime_.jsx(Layout/* default */.Z, {
    children: whyChooseUsData !== null && whyChooseUsData !== void 0 && whyChooseUsData.isFlipBook ? /*#__PURE__*/jsx_runtime_.jsx("iframe", {
      allowFullScreen: true,
      scrolling: "no",
      className: "fp-iframe",
      src: whyChooseUsData === null || whyChooseUsData === void 0 ? void 0 : whyChooseUsData.flipBookLink,
      style: {
        border: '1px solid lightgray',
        width: '100%',
        height: '600px'
      }
    }) : /*#__PURE__*/jsx_runtime_.jsx(AboutUsDetailsComponent, {
      whyChooseUsData: whyChooseUsData
    })
  });
}
async function getServerSideProps(context) {
  const id = context.query.id;
  await db/* default.connect */.Z.connect();
  const whyChooseUsDoc = await WhyChooseUs/* default.findById */.Z.findById(id).lean();
  return {
    props: {
      whyChooseUsData: db/* default.convertDocToObj */.Z.convertDocToObj(whyChooseUsDoc)
    }
  };
}

/***/ }),

/***/ 874:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 2737:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Dashboard");

/***/ }),

/***/ 1041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HelpCenter");

/***/ }),

/***/ 1090:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 9613:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 586:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Login");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 4734:
/***/ ((module) => {

module.exports = require("@mui/icons-material/School");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 3801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 7949:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8035:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3061,2236,6420,3391,3296], () => (__webpack_exec__(8890)));
module.exports = __webpack_exports__;

})();