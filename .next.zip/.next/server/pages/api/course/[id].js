"use strict";
(() => {
var exports = {};
exports.id = 5295;
exports.ids = [5295];
exports.modules = {

/***/ 1864:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9303);
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_connect__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2898);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6420);
/* harmony import */ var _models_Course__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3291);




const handler = next_connect__WEBPACK_IMPORTED_MODULE_0___default()();
handler.get(async (req, res) => {
  await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* .default.connect */ .Z.connect();
  const course = await _models_Course__WEBPACK_IMPORTED_MODULE_3__/* .default.findById */ .Z.findById(req.query.id).populate('category');
  res.send(course);
});
handler.use(_utils_auth__WEBPACK_IMPORTED_MODULE_1__/* .isAuth */ .$D, _utils_auth__WEBPACK_IMPORTED_MODULE_1__/* .isAdmin */ .GJ);
handler.put(async (req, res) => {
  await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* .default.connect */ .Z.connect();
  const course = await _models_Course__WEBPACK_IMPORTED_MODULE_3__/* .default.findById */ .Z.findById(req.query.id);

  if (course) {
    course.name = req.body.name;
    course.slug = req.body.slug;
    course.category = req.body.category;
    course.subCategory = req.body.subCategory;
    course.image = req.body.image;
    course.price = req.body.price;
    course.languageMedium = req.body.languageMedium;
    course.offerInPercentage = req.body.offerInPercentage;
    course.isFeatured = req.body.isFeatured;
    course.isOffered = req.body.isOffered;
    course.docStatus = req.body.docStatus;
    course.description = req.body.description;
    await course.save();
    res.send({
      message: 'Course Updated Successfully'
    });
  } else {
    res.status(404).send({
      message: 'Course Not Found'
    });
  }
});
handler.delete(async (req, res) => {
  await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* .default.connect */ .Z.connect();
  const course = await _models_Course__WEBPACK_IMPORTED_MODULE_3__/* .default.findById */ .Z.findById(req.query.id);

  if (course) {
    await course.remove();
    res.send({
      message: 'Course Deleted'
    });
  } else {
    res.status(404).send({
      message: 'Course Not Found'
    });
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

/***/ }),

/***/ 9722:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6420,2898,3291], () => (__webpack_exec__(1864)));
module.exports = __webpack_exports__;

})();