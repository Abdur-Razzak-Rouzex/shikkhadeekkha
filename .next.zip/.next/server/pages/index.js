"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 1430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const testimonialSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  avatar: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  designation: {
    type: String
  },
  message: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});
const User = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Testimonial) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Testimonial', testimonialSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);

/***/ }),

/***/ 7979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: ./components/Layout.js + 2 modules
var Layout = __webpack_require__(1783);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(6420);
// EXTERNAL MODULE: ./models/Course.js
var Course = __webpack_require__(3291);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./utils/Store.js
var Store = __webpack_require__(2236);
// EXTERNAL MODULE: ./components/ProductItem.js
var ProductItem = __webpack_require__(4486);
;// CONCATENATED MODULE: external "react-responsive-carousel"
const external_react_responsive_carousel_namespaceObject = require("react-responsive-carousel");
// EXTERNAL MODULE: ./utils/classes.js
var classes = __webpack_require__(3391);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/homepage/TopLineSection/index.js




const TopLineSection = ({
  topline
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
    sx: {
      marginY: 10,
      textAlign: 'center'
    },
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      variant: "h1",
      sx: {
        fontFamily: "cursive",
        fontWeight: 700,
        fontSize: "2rem"
      },
      children: topline.title
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      variant: "subtitle1",
      sx: {
        color: "#928a8a",
        fontFamily: "cursive"
      },
      children: topline.description
    })]
  });
};

/* harmony default export */ const homepage_TopLineSection = (TopLineSection);
// EXTERNAL MODULE: ./components/homepage/whyChooseUsSection/index.js
var whyChooseUsSection = __webpack_require__(9876);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./utils/error.js
var utils_error = __webpack_require__(9873);
// EXTERNAL MODULE: external "notistack"
var external_notistack_ = __webpack_require__(3308);
;// CONCATENATED MODULE: ./components/common/Section.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function Section(props) {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, _objectSpread({
    py: 7,
    component: "section"
  }, props));
}
;// CONCATENATED MODULE: ./components/common/TitleAndSubtitle.js



function TitleAndSubtitle({
  title,
  subtitle
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
    mb: 2,
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      variant: "h5",
      align: "center",
      component: "h2",
      children: title
    }), subtitle && /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
      variant: "overline",
      align: "center",
      component: "h2",
      children: subtitle
    })]
  });
}
;// CONCATENATED MODULE: ./components/homepage/testimonialsCarouselSection/index.js






function TestimonialsCarousel({
  items,
  title,
  subtitle
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Section, {
    children: [title && /*#__PURE__*/jsx_runtime_.jsx(TitleAndSubtitle, {
      title: title,
      subtitle: subtitle
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Card, {
      sx: {
        margin: 0
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(external_react_responsive_carousel_namespaceObject.Carousel, {
        showArrows: false,
        showThumbs: false,
        autoPlay: true,
        infiniteLoop: true,
        interval: 5000,
        transitionTime: 1000,
        showStatus: false,
        children: items === null || items === void 0 ? void 0 : items.map((item, key) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Card, {
          sx: {
            paddingTop: 5
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Avatar, {
            loading: "lazy",
            sx: {
              width: 74,
              height: 74,
              margin: 'auto'
            },
            src: item === null || item === void 0 ? void 0 : item.avatar
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.CardContent, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              align: "center",
              variant: "h5",
              component: "h4",
              children: item === null || item === void 0 ? void 0 : item.name
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              variant: "subtitle1",
              sx: {
                color: "#928a8a",
                fontFamily: "cursive",
                lineHeight: 1,
                marginLeft: 10
              },
              children: item === null || item === void 0 ? void 0 : item.designation
            }), /*#__PURE__*/jsx_runtime_.jsx("blockquote", {
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                variant: "body1",
                align: "center",
                component: "p",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("em", {
                  children: ["\"", item === null || item === void 0 ? void 0 : item.message, "\""]
                })
              })
            })]
          })]
        }, key))
      })
    })]
  });
}
// EXTERNAL MODULE: ./models/Testimonial.js
var Testimonial = __webpack_require__(1430);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./pages/index.js
function pages_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function pages_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { pages_ownKeys(Object(source), true).forEach(function (key) { pages_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { pages_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function pages_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }























function Home(props) {
  const {
    state,
    dispatch
  } = (0,external_react_.useContext)(Store/* Store */.y);
  const {
    allTestimonials,
    featuredCourses
  } = props;
  const {
    enqueueSnackbar
  } = (0,external_notistack_.useSnackbar)();
  const {
    0: banners,
    1: setBanners
  } = (0,external_react_.useState)([]);
  const {
    0: whyChooseUs,
    1: setWhyChooseUs
  } = (0,external_react_.useState)([]);
  const {
    0: loader,
    1: setLoader
  } = (0,external_react_.useState)(false);
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const getBanners = async () => {
      setLoader(true);

      try {
        const [bannersData, whyChooseUsData] = await Promise.all([external_axios_default().get('/api/admin/hero-banner'), external_axios_default().get('/api/why-choose-us', {
          params: {
            from: 'client'
          }
        })]);
        setBanners(bannersData.data);
        setWhyChooseUs(whyChooseUsData.data);
        setLoader(false);
      } catch (error) {
        enqueueSnackbar((0,utils_error/* getError */.b)(error), {
          variant: 'error'
        });
        setLoader(false);
      }
    };

    getBanners();
  }, []);
  const topLine = {
    title: 'the title',
    description: 'A short and strong description'
  };

  const addToCartHandler = async item => {
    if ((item === null || item === void 0 ? void 0 : item.type) === 'course') {
      router.push(`/product/${item === null || item === void 0 ? void 0 : item.slug}`);
    } else {
      const existItem = state.cart.cartItems.find(x => x._id === (item === null || item === void 0 ? void 0 : item._id));
      const quantity = existItem ? existItem.quantity + 1 : 1;
      const {
        data
      } = await external_axios_default().get(`/api/products/${item === null || item === void 0 ? void 0 : item._id}`);

      if (data.countInStock < quantity) {
        enqueueSnackbar('Sorry. Product is out of stock', {
          variant: 'error'
        });
        return;
      }

      dispatch({
        type: 'CART_ADD_ITEM',
        payload: pages_objectSpread(pages_objectSpread({}, item), {}, {
          quantity
        })
      });
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
    children: [loader ? /*#__PURE__*/jsx_runtime_.jsx(material_.Skeleton, {
      variant: "rectangular",
      height: "60vh",
      width: "100%"
    }) : /*#__PURE__*/jsx_runtime_.jsx(external_react_responsive_carousel_namespaceObject.Carousel, {
      showThumbs: false,
      autoPlay: true,
      infiniteLoop: true,
      interval: 5000,
      transitionTime: 1000,
      children: banners.map(heroBanner => /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: `/${heroBanner.link}`,
        passHref: true,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
          sx: classes/* default.flex */.Z.flex,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: heroBanner.imgUrl,
            alt: heroBanner.altTitle,
            width: 1500,
            height: 500
          })
        })
      }, heroBanner._id))
    }), /*#__PURE__*/jsx_runtime_.jsx(homepage_TopLineSection, {
      topline: topLine
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      mt: 5,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h2",
          children: "Featured Courses"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 6,
        sx: {
          textAlign: 'end',
          margin: 'auto'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
          size: "small",
          color: "secondary",
          variant: "contained",
          href: "/search",
          children: "View All"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
      container: true,
      spacing: 3,
      children: featuredCourses.map(course => /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        md: 4,
        children: /*#__PURE__*/jsx_runtime_.jsx(ProductItem/* default */.Z, {
          item: course,
          addToCartHandler: addToCartHandler
        })
      }, course.name))
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      mt: 5,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h2",
          children: "Know More About Our Programs, Products & Courses"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 6,
        sx: {
          textAlign: 'end',
          margin: 'auto'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
          size: "small",
          color: "secondary",
          variant: "contained",
          href: "/about-us",
          children: "View All"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(whyChooseUsSection/* default */.Z, {
      items: whyChooseUs
    }), /*#__PURE__*/jsx_runtime_.jsx(TestimonialsCarousel, {
      title: "Testimonials",
      subtitle: "Our clients are happy!",
      items: allTestimonials
    })]
  });
}
async function getServerSideProps() {
  await db/* default.connect */.Z.connect();
  /*    const topRatedProductsDocs = await Product.find({}, '-reviews')
          .lean()
          .sort({
              rating: -1,
          })
          .limit(3);*/

  const featuredCoursesDocs = await Course/* default.find */.Z.find({
    isFeatured: true,
    docStatus: true
  }, ['-reviews', '-category']).lean().limit(3);
  const testimonialDocs = await Testimonial/* default.find */.Z.find({}).lean();
  return {
    props: {
      /*topRatedProducts: topRatedProductsDocs.map(db.convertDocToObj),*/
      featuredCourses: featuredCoursesDocs.map(db/* default.convertDocToObj */.Z.convertDocToObj),
      allTestimonials: testimonialDocs.map(db/* default.convertDocToObj */.Z.convertDocToObj)
    }
  };
}

/***/ }),

/***/ 9873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getError),
/* harmony export */   "q": () => (/* binding */ onError)
/* harmony export */ });
const getError = err => {
  var _err$response$data$me, _err$response, _err$response$data;

  return (_err$response$data$me = err === null || err === void 0 ? void 0 : (_err$response = err.response) === null || _err$response === void 0 ? void 0 : (_err$response$data = _err$response.data) === null || _err$response$data === void 0 ? void 0 : _err$response$data.message) !== null && _err$response$data$me !== void 0 ? _err$response$data$me : err.message;
};

const onError = async (err, req, res, next) => {
  res.status(500).send({
    message: err.toString()
  });
};



/***/ }),

/***/ 874:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 2737:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Dashboard");

/***/ }),

/***/ 1041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HelpCenter");

/***/ }),

/***/ 1090:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 9613:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 586:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Login");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 4734:
/***/ ((module) => {

module.exports = require("@mui/icons-material/School");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 3801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 7949:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 4459:
/***/ ((module) => {

module.exports = require("@mui/material/Rating");

/***/ }),

/***/ 8035:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3308:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3061,2236,6420,3391,3296,3291,4486,9876], () => (__webpack_exec__(7979)));
module.exports = __webpack_exports__;

})();