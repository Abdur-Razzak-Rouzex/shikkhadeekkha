"use strict";
(() => {
var exports = {};
exports.id = 9603;
exports.ids = [9603];
exports.modules = {

/***/ 1971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Search),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8759);
/* harmony import */ var _mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1783);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6420);
/* harmony import */ var _utils_classes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3391);
/* harmony import */ var _components_ProductItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4486);
/* harmony import */ var _utils_Store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2236);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4459);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3308);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _models_Course__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3291);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















const PAGE_SIZE = 12;
const prices = [{
  name: '1 tk to 100 tk',
  value: '1-100'
}, {
  name: '101 tk to 500 tk',
  value: '101-500'
}, {
  name: ' 501tk to 1,000 tk',
  value: '501-1000'
}, {
  name: ' 1,001tk to 3,000 tk',
  value: '1001-3000'
}, {
  name: ' 3,001tk to 5,000 tk',
  value: '3001-5000'
}, {
  name: ' 5,001tk to 10,000 tk',
  value: '5001-10000'
}];
const ratings = [1, 2, 3, 4, 5];
function Search(props) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const {
    enqueueSnackbar
  } = (0,notistack__WEBPACK_IMPORTED_MODULE_11__.useSnackbar)();
  const {
    query = 'all',
    subCategory = 'all',
    brand = 'all',
    price = 'all',
    rating = 'all',
    sort = 'featured'
  } = router.query;
  /*const {courses, countProducts, categories, brands, pages} = props;*/

  const {
    courses,
    countProducts,
    subCategories,
    brands,
    pages
  } = props;
  /*const filterSearch = ({page, category, brand, sort, min, max, searchQuery, price, rating,}) => {*/

  const filterSearch = ({
    page,
    subCategory,
    brand,
    sort,
    min,
    max,
    searchQuery,
    price,
    rating
  }) => {
    const path = router.pathname;
    const {
      query
    } = router;
    if (page) query.page = page;
    if (searchQuery) query.searchQuery = searchQuery;
    if (sort) query.sort = sort;
    /*if (category) query.category = category;*/

    if (subCategory) query.subCategory = subCategory;
    if (brand) query.brand = brand;
    if (price) query.price = price;
    if (rating) query.rating = rating;
    if (min) query.min ? query.min : query.min === 0 ? 0 : min;
    if (max) query.max ? query.max : query.max === 0 ? 0 : max;
    router.push({
      pathname: path,
      query: query
    });
  };
  /*    const categoryHandler = (e) => {
          filterSearch({category: e.target.value});
      };*/


  const subCategoryHandler = e => {
    filterSearch({
      subCategory: e.target.value
    });
  };

  const pageHandler = (e, page) => {
    filterSearch({
      page
    });
  };

  const brandHandler = e => {
    filterSearch({
      brand: e.target.value
    });
  };

  const sortHandler = e => {
    filterSearch({
      sort: e.target.value
    });
  };

  const priceHandler = e => {
    filterSearch({
      price: e.target.value
    });
  };

  const ratingHandler = e => {
    filterSearch({
      rating: e.target.value
    });
  };

  const {
    state,
    dispatch
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_utils_Store__WEBPACK_IMPORTED_MODULE_8__/* .Store */ .y);

  const addToCartHandler = async item => {
    if ((item === null || item === void 0 ? void 0 : item.type) === 'course') {
      router.push(`/product/${item === null || item === void 0 ? void 0 : item.slug}`);
    } else {
      const existItem = state.cart.cartItems.find(x => x._id === (item === null || item === void 0 ? void 0 : item._id));
      const quantity = existItem ? existItem.quantity + 1 : 1;
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_9___default().get(`/api/products/${item === null || item === void 0 ? void 0 : item._id}`);

      if (data.countInStock < quantity) {
        enqueueSnackbar('Sorry. Product is out of stock', {
          variant: 'error'
        });
        return;
      }

      dispatch({
        type: 'CART_ADD_ITEM',
        payload: _objectSpread(_objectSpread({}, item), {}, {
          quantity
        })
      });
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_Layout__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    title: "search",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
      sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.section */ .Z.section,
      container: true,
      spacing: 1,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        md: 3,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.List, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.ListItem, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box, {
              sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.fullWidth */ .Z.fullWidth,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
                children: "Sub-Categories"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Select, {
                fullWidth: true,
                value: subCategory,
                onChange: subCategoryHandler,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: "all",
                  children: "All"
                }), subCategories && subCategories.map(subCategory => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: subCategory,
                  children: subCategory
                }, subCategory))]
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.ListItem, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box, {
              sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.fullWidth */ .Z.fullWidth,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
                children: "Brands"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Select, {
                value: brand,
                onChange: brandHandler,
                fullWidth: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: "all",
                  children: "All"
                }), brands && brands.map(brand => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: brand,
                  children: brand
                }, brand))]
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.ListItem, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box, {
              sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.fullWidth */ .Z.fullWidth,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
                children: "Prices"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Select, {
                value: price,
                onChange: priceHandler,
                fullWidth: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: "all",
                  children: "All"
                }), prices.map(price => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: price.value,
                  children: price.name
                }, price.value))]
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.ListItem, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box, {
              sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.fullWidth */ .Z.fullWidth,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
                children: "Ratings"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Select, {
                value: rating,
                onChange: ratingHandler,
                fullWidth: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  value: "all",
                  children: "All"
                }), ratings.map(rating => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                  dispaly: "flex",
                  value: rating,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_10___default()), {
                    value: rating,
                    readOnly: true
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
                    component: "span",
                    children: "& Up"
                  })]
                }, rating))]
              })]
            })
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
        item: true,
        md: 9,
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          container: true,
          justifyContent: "space-between",
          alignItems: "center",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
            item: true,
            children: [courses.length === 0 ? 'No' : countProducts, " Results", query !== 'all' && query !== '' && ' : ' + query, subCategory !== 'all' && ' : ' + subCategory, brand !== 'all' && ' : ' + brand, price !== 'all' && ' : Price ' + price, rating !== 'all' && ' : Rating ' + rating + ' & up', query !== 'all' && query !== '' ||
            /*category !== 'all' ||*/
            subCategory !== 'all' || brand !== 'all' || rating !== 'all' || price !== 'all' ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
              onClick: () => router.push('/search'),
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx((_mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_1___default()), {})
            }) : null]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
            item: true,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
              component: "span",
              sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.sort */ .Z.sort,
              children: "Sort by"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Select, {
              value: sort,
              onChange: sortHandler,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                value: "featured",
                children: "Featured"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                value: "lowest",
                children: "Price: Low to High"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                value: "highest",
                children: "Price: High to Low"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                value: "toprated",
                children: "Customer Reviews"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.MenuItem, {
                value: "newest",
                children: "Newest Arrivals"
              })]
            })]
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
          sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.section */ .Z.section,
          container: true,
          spacing: 3,
          children: courses.map(product => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
            item: true,
            md: 4,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_components_ProductItem__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
              item: product,
              addToCartHandler: addToCartHandler
            })
          }, product.name))
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Pagination, {
          sx: _utils_classes__WEBPACK_IMPORTED_MODULE_6__/* .default.section */ .Z.section,
          defaultPage: parseInt(query.page || '1'),
          count: pages,
          onChange: pageHandler
        })]
      })]
    })
  });
}
async function getServerSideProps({
  query
}) {
  await _utils_db__WEBPACK_IMPORTED_MODULE_5__/* .default.connect */ .Z.connect();
  const pageSize = query.pageSize || PAGE_SIZE;
  const page = query.page || 1;
  /*const category = query.category || '';*/

  const subcategory = query.subCategory || '';
  const brand = query.brand || '';
  const price = query.price || '';
  const rating = query.rating || '';
  const sort = query.sort || '';
  const searchQuery = query.query || '';
  const queryFilter = searchQuery && searchQuery !== 'all' ? {
    name: {
      $regex: searchQuery,
      $options: 'i'
    }
  } : {};
  /*const categoryFilter = category && category !== 'all' ? {category} : {};*/

  const subCategoryFilter = subcategory && subcategory !== 'all' ? {
    subcategory
  } : {};
  const brandFilter = brand && brand !== 'all' ? {
    brand
  } : {};
  const ratingFilter = rating && rating !== 'all' ? {
    rating: {
      $gte: Number(rating)
    }
  } : {}; // 10-50

  const priceFilter = price && price !== 'all' ? {
    price: {
      $gte: Number(price.split('-')[0]),
      $lte: Number(price.split('-')[1])
    }
  } : {};
  const order = sort === 'featured' ? {
    featured: -1
  } : sort === 'lowest' ? {
    price: 1
  } : sort === 'highest' ? {
    price: -1
  } : sort === 'toprated' ? {
    rating: -1
  } : sort === 'newest' ? {
    createdAt: -1
  } : {
    _id: -1
  };
  /*const categories = await Category.find();*/

  const subCategories = await _models_Course__WEBPACK_IMPORTED_MODULE_12__/* .default.find */ .Z.find().distinct('subCategory');
  const brands = await _models_Course__WEBPACK_IMPORTED_MODULE_12__/* .default.find */ .Z.find().distinct('brand');
  const courseDocs = await _models_Course__WEBPACK_IMPORTED_MODULE_12__/* .default.find */ .Z.find(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, queryFilter), subCategoryFilter), priceFilter), brandFilter), ratingFilter), ['-reviews', '-category']).sort(order).skip(pageSize * (page - 1)).limit(pageSize).lean();
  const countProducts = await _models_Course__WEBPACK_IMPORTED_MODULE_12__/* .default.countDocuments */ .Z.countDocuments(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, queryFilter), subCategoryFilter), priceFilter), brandFilter), ratingFilter));
  const courses = courseDocs.map(_utils_db__WEBPACK_IMPORTED_MODULE_5__/* .default.convertDocToObj */ .Z.convertDocToObj);
  return {
    props: {
      courses,
      countProducts,
      page,
      pages: Math.ceil(countProducts / pageSize),

      /*categories,*/
      subCategories,
      brands
    }
  };
}

/***/ }),

/***/ 874:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 8759:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Cancel");

/***/ }),

/***/ 2737:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Dashboard");

/***/ }),

/***/ 1041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HelpCenter");

/***/ }),

/***/ 1090:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 9613:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 586:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Login");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 4734:
/***/ ((module) => {

module.exports = require("@mui/icons-material/School");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 3801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 7949:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 4459:
/***/ ((module) => {

module.exports = require("@mui/material/Rating");

/***/ }),

/***/ 8035:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3308:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3061,2236,6420,3391,3296,3291,4486], () => (__webpack_exec__(1971)));
module.exports = __webpack_exports__;

})();