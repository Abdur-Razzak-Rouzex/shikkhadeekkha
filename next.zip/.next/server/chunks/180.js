"use strict";
exports.id = 180;
exports.ids = [180];
exports.modules = {

/***/ 180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FilePondUploader)
/* harmony export */ });
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7796);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_filepond__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5264);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






(0,react_filepond__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)((filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_1___default()));
function FilePondUploader({
  getUrl,
  id,
  required = false,
  title = 'Drag & Drop your files or'
}) {
  const {
    0: files,
    1: setFiles
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_filepond__WEBPACK_IMPORTED_MODULE_0__.FilePond, {
    required: required,
    id: id,
    files: files,
    onupdatefiles: setFiles,
    server: {
      process: {
        url: "/api/upload",
        onload: response => {
          let res = JSON.parse(response);
          getUrl(res === null || res === void 0 ? void 0 : res.secure_url);
          return 1;
        }
      }
    },
    name: "file",
    labelIdle: `${title} or <span class="filepond--label-action">Browse</span>`
  });
}

/***/ })

};
;