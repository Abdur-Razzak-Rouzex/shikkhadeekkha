exports.id = 3296;
exports.ids = [3296];
exports.modules = {

/***/ 1783:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8035);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./utils/classes.js
var classes = __webpack_require__(3391);
// EXTERNAL MODULE: ./utils/Store.js
var Store = __webpack_require__(2236);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(1893);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3903);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/Home"
var Home_ = __webpack_require__(1090);
var Home_default = /*#__PURE__*/__webpack_require__.n(Home_);
// EXTERNAL MODULE: external "@mui/icons-material/ShoppingCart"
var ShoppingCart_ = __webpack_require__(3801);
var ShoppingCart_default = /*#__PURE__*/__webpack_require__.n(ShoppingCart_);
// EXTERNAL MODULE: external "@mui/icons-material/AccountCircle"
var AccountCircle_ = __webpack_require__(874);
var AccountCircle_default = /*#__PURE__*/__webpack_require__.n(AccountCircle_);
// EXTERNAL MODULE: external "@mui/icons-material/Dashboard"
var Dashboard_ = __webpack_require__(2737);
var Dashboard_default = /*#__PURE__*/__webpack_require__.n(Dashboard_);
// EXTERNAL MODULE: external "@mui/icons-material/Login"
var Login_ = __webpack_require__(586);
var Login_default = /*#__PURE__*/__webpack_require__.n(Login_);
// EXTERNAL MODULE: external "@mui/icons-material/Info"
var Info_ = __webpack_require__(9613);
var Info_default = /*#__PURE__*/__webpack_require__.n(Info_);
// EXTERNAL MODULE: external "@mui/icons-material/HelpCenter"
var HelpCenter_ = __webpack_require__(1041);
var HelpCenter_default = /*#__PURE__*/__webpack_require__.n(HelpCenter_);
// EXTERNAL MODULE: external "@mui/icons-material/School"
var School_ = __webpack_require__(4734);
var School_default = /*#__PURE__*/__webpack_require__.n(School_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Header.js





















const Header = () => {
  const {
    state,
    dispatch
  } = (0,external_react_.useContext)(Store/* Store */.y);
  const {
    darkMode,
    cart,
    userInfo
  } = state;
  const {
    0: query,
    1: setQuery
  } = (0,external_react_.useState)('');
  const router = (0,router_.useRouter)();

  const queryChangeHandler = e => {
    setQuery(e.target.value);
  };

  const redirectTo = path => {
    router.push(path);
    setShowDrawer(false);
  };

  const submitHandler = e => {
    e.preventDefault();
    router.push(`/search?query=${query}`);
  };

  const darkModeChangeHandler = () => {
    dispatch({
      type: darkMode ? 'DARK_MODE_OFF' : 'DARK_MODE_ON'
    });
    const newDarkMode = !darkMode;
    external_js_cookie_default().set('darkMode', newDarkMode ? 'ON' : 'OFF');
  };

  const {
    0: showDrawer,
    1: setShowDrawer
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.AppBar, {
      position: "static",
      sx: classes/* default.appbar */.Z.appbar,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Toolbar, {
        sx: classes/* default.toolbar */.Z.toolbar,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          display: "flex",
          alignItems: "center",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            passHref: true,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Link, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                sx: classes/* default.brand */.Z.brand,
                children: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09A6\u09C0\u0995\u09CD\u09B7\u09BE"
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                variant: "span",
                sx: {
                  fontSize: 12,
                  marginLeft: '22px'
                },
                children: "\u09AE\u09A8\u09A8\u09C7 \u09B8\u09C3\u09B7\u09CD\u099F\u09BF\u09B0 \u09AC\u09BF\u0995\u09BE\u09B6"
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Hidden, {
          mdUp: true,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
            edge: "start",
            color: "inherit",
            "aria-label": "menu",
            onClick: () => setShowDrawer(true),
            children: /*#__PURE__*/jsx_runtime_.jsx((Menu_default()), {
              sx: {
                color: 'white'
              }
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Hidden, {
          smDown: true,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
            mx: "auto",
            children: /*#__PURE__*/jsx_runtime_.jsx("form", {
              onSubmit: submitHandler,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
                sx: classes/* default.searchForm */.Z.searchForm,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.InputBase, {
                  name: "query",
                  sx: classes/* default.searchInput */.Z.searchInput,
                  placeholder: "Search products",
                  onChange: queryChangeHandler
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
                  type: "submit",
                  sx: classes/* default.searchButton */.Z.searchButton,
                  "aria-label": "search",
                  children: /*#__PURE__*/jsx_runtime_.jsx((Search_default()), {})
                })]
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Hidden, {
          smDown: true,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Switch, {
              checked: darkMode,
              onChange: darkModeChangeHandler
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/cart",
              passHref: true,
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  component: "span",
                  children: cart.cartItems.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(material_.Badge, {
                    color: "secondary",
                    badgeContent: cart.cartItems.length,
                    children: /*#__PURE__*/jsx_runtime_.jsx((ShoppingCart_default()), {})
                  }) : 'Cart'
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/about-us",
              passHref: true,
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  component: "span",
                  children: "About Us"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/FAQs",
              passHref: true,
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  component: "span",
                  children: "FAQs"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/admission-form/student-info",
              passHref: true,
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  component: "span",
                  children: "Admission"
                })
              })
            }), userInfo ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/profile",
                passHref: true,
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    component: "span",
                    children: userInfo.name
                  })
                })
              }), userInfo.isAdmin && /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "/admin/dashboard",
                passHref: true,
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                  children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                    component: "span",
                    children: "Dashboard"
                  })
                })
              })]
            }) : /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/login",
              passHref: true,
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  component: "span",
                  children: "Login"
                })
              })
            })]
          })
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Drawer, {
      anchor: "right",
      open: showDrawer,
      onClose: () => setShowDrawer(false),
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.List, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
          children: /*#__PURE__*/jsx_runtime_.jsx("form", {
            onSubmit: submitHandler,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
              sx: classes/* default.searchForm */.Z.searchForm,
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.InputBase, {
                name: "query",
                sx: classes/* default.searchInput */.Z.searchInput,
                placeholder: "Search products",
                onChange: queryChangeHandler
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.IconButton, {
                type: "submit",
                sx: classes/* default.searchButton */.Z.searchButton,
                "aria-label": "search",
                children: /*#__PURE__*/jsx_runtime_.jsx((Search_default()), {})
              })]
            })
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: darkMode ? 'Light Mode' : 'Dark Mode'
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Switch, {
              checked: darkMode,
              onChange: darkModeChangeHandler
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          onClick: () => redirectTo('/'),
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: "Home"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: /*#__PURE__*/jsx_runtime_.jsx((Home_default()), {})
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          onClick: () => redirectTo('/cart'),
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: "Cart"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: cart.cartItems.length > 0 ? /*#__PURE__*/jsx_runtime_.jsx(material_.Badge, {
              color: "secondary",
              badgeContent: cart.cartItems.length,
              children: /*#__PURE__*/jsx_runtime_.jsx((ShoppingCart_default()), {})
            }) : /*#__PURE__*/jsx_runtime_.jsx((ShoppingCart_default()), {})
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          onClick: () => redirectTo('/about-us'),
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: "About Us"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: /*#__PURE__*/jsx_runtime_.jsx((Info_default()), {})
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          onClick: () => redirectTo('/FAQs'),
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: "FAQs"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: /*#__PURE__*/jsx_runtime_.jsx((HelpCenter_default()), {})
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          onClick: () => redirectTo('/admission-form/student-info'),
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: "Admission"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: /*#__PURE__*/jsx_runtime_.jsx((School_default()), {})
          })]
        }), userInfo ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
            button: true,
            onClick: () => redirectTo('/profile'),
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
              primary: userInfo.name
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
              children: /*#__PURE__*/jsx_runtime_.jsx((AccountCircle_default()), {})
            })]
          }), userInfo.isAdmin && /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
            button: true,
            onClick: () => redirectTo('/admin/dashboard'),
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
              primary: "Dashboard"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
              children: /*#__PURE__*/jsx_runtime_.jsx((Dashboard_default()), {})
            })]
          })]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
          button: true,
          onClick: () => redirectTo('/login'),
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItemText, {
            primary: "Login"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItemIcon, {
            children: /*#__PURE__*/jsx_runtime_.jsx((Login_default()), {})
          })]
        })]
      })
    })]
  });
};

/* harmony default export */ const components_Header = (Header);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Footer.js








const Footer = () => {
  return /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
    component: "footer",
    sx: classes/* default.footer */.Z.footer,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        item: true,
        md: 4,
        xs: 12,
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/about-us",
          passHref: true,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              children: "About Us"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/search",
          passHref: true,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              children: "See More Products"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/admission",
          passHref: true,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              children: "Take Admission"
            })
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        item: true,
        md: 4,
        xs: 12,
        sx: {
          margin: 'auto',
          textAlign: 'center'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/images/logo.png",
          alt: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09A6\u09C0\u0995\u09CD\u09B7\u09BE",
          title: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09A6\u09C0\u0995\u09CD\u09B7\u09BE",
          width: 200,
          height: 200
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          sx: {
            color: 'white'
          },
          children: "All rights reserved. \xA9 Copyright 2022 ShikkhaDeekkha"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        md: 4,
        xs: 12,
        sx: {
          display: 'flex',
          justifyContent: 'end',
          margin: 'auto'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          passHref: true,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Link, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: classes/* default.brand */.Z.brand,
              children: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09A6\u09C0\u0995\u09CD\u09B7\u09BE"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              variant: "span",
              sx: {
                fontSize: 12,
                marginLeft: '22px'
              },
              children: "\u09AE\u09A8\u09A8\u09C7 \u09B8\u09C3\u09B7\u09CD\u099F\u09BF\u09B0 \u09AC\u09BF\u0995\u09BE\u09B6"
            })]
          })
        })
      })]
    })
  });
};

/* harmony default export */ const components_Footer = (Footer);
;// CONCATENATED MODULE: ./components/Layout.js











function Layout({
  title,
  description,
  children
}) {
  const {
    state
  } = (0,external_react_.useContext)(Store/* Store */.y);
  const {
    darkMode
  } = state;
  const theme = (0,styles_.createTheme)({
    components: {
      MuiLink: {
        defaultProps: {
          underline: 'none'
        }
      }
    },
    typography: {
      h1: {
        fontSize: '1.6rem',
        fontWeight: 400,
        margin: '1rem 0'
      },
      h2: {
        fontSize: '1.4rem',
        fontWeight: 400,
        margin: '1rem 0'
      }
    },
    palette: {
      mode: darkMode ? 'dark' : 'light',
      primary: {
        main: '#f0c000'
      },
      secondary: {
        main: '#208080'
      },
      error: {
        main: '#d32f2f'
      },
      warning: {
        main: '#ED6C02'
      }
    }
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: title ? `${title} - শিক্ষাদীক্ষা` : 'শিক্ষাদীক্ষা'
      }), description && /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: description
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ThemeProvider, {
      theme: theme,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.CssBaseline, {}), /*#__PURE__*/jsx_runtime_.jsx(components_Header, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Container, {
        component: "main",
        sx: classes/* default.main */.Z.main,
        children: children
      }), /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
    })]
  });
}

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;