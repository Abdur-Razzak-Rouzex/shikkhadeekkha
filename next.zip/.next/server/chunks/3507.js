"use strict";
exports.id = 3507;
exports.ids = [3507];
exports.modules = {

/***/ 3507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const admissionFormSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  user: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
    ref: 'User',
    required: true
  },
  studentInfo: {
    studentNameBn: {
      type: String,
      required: true
    },
    studentNameEn: {
      type: String,
      required: true
    },
    dateOfBirth: {
      type: Date,
      required: true
    },
    studentClass: {
      type: String,
      required: true
    },
    instituteName: {
      type: String,
      required: true
    },
    educationMedium: {
      type: String,
      required: true
    },
    passportSizePhotoUrl: {
      type: String,
      required: true
    }
  },
  parentsInfo: {
    fatherName: {
      type: String,
      required: true
    },
    fatherProfession: {
      type: String,
      required: true
    },
    motherName: {
      type: String,
      required: true
    },
    motherProfession: {
      type: String,
      required: true
    },
    parentsDirectContact: {
      type: String,
      required: true
    },
    parentsWhatsappNumber: {
      type: String,
      required: true
    },
    parentsEmail: {
      type: String,
      required: true
    },
    academicallyResponsiblePerson: {
      type: String,
      required: true
    }
  },
  academicGuardianInfo: {
    guardianName: {
      type: String
    },
    relation: {
      type: String
    },
    guardianMobileNumber: {
      type: String
    },
    guardianWhatsappNumber: {
      type: String
    },
    guardianEmail: {
      type: String
    }
  },
  otherInfo: {
    selectedCourse: {
      type: String,
      required: true
    },
    studentGroupWhatsappNo: {
      type: String,
      required: true
    },
    studentGmailId: {
      type: String,
      required: true
    },
    residentForCourier: {
      type: String,
      required: true
    },
    typeOfElectronicsToBeUsedInLiveClass: [{
      type: String
    }],
    coCurricularActivities: [{
      type: String
    }]
  }
}, {
  timestamps: true
});
const User = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.AdmissionForm) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('AdmissionForm', admissionFormSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);

/***/ })

};
;