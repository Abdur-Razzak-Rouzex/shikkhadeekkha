"use strict";
exports.id = 3878;
exports.ids = [3878];
exports.modules = {

/***/ 3878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3308);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_error__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9873);
/* harmony import */ var _components_common_modals_HookFormMuiModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(214);
/* harmony import */ var _components_common_button_SubmitButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7324);
/* harmony import */ var _components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6504);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_Store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2236);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
const _excluded = ["itemId", "refreshDataTable"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

















const initialValues = {
  avatar: '',
  name: '',
  designation: '',
  message: ''
};

const TestimonialAddEditPopup = _ref => {
  var _errors$avatar$messag, _errors$avatar, _errors$name$message, _errors$name, _errors$designation$m, _errors$designation, _errors$message$messa, _errors$message;

  let {
    itemId,
    refreshDataTable
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    enqueueSnackbar
  } = (0,notistack__WEBPACK_IMPORTED_MODULE_4__.useSnackbar)();
  const isEdit = itemId != null;
  const {
    0: loadingUpload,
    1: setLoadingUpload
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
  const {
    state
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_utils_Store__WEBPACK_IMPORTED_MODULE_10__/* .Store */ .y);
  const {
    userInfo
  } = state;
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
  const {
    0: itemData,
    1: setItemData
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(initialValues);
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (!(userInfo !== null && userInfo !== void 0 && userInfo.name)) {
      router.push('/login');
    }

    const getTestimonials = async () => {
      try {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_9___default().get(`/api/testimonial/${itemId}`, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        setItemData(data);
      } catch (error) {
        enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
          variant: 'error'
        });
      }
    };

    if (itemId) {
      getTestimonials();
    }
  }, [itemId]);
  const validationSchema = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    return yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      avatar: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Avatar: Small sized image"),
      name: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Name"),
      designation: yup__WEBPACK_IMPORTED_MODULE_0__.string().label("Designation"),
      message: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Message")
    });
  }, []);
  const {
    register,
    reset,
    handleSubmit,
    getValues,
    formState: {
      errors,
      isSubmitting
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(validationSchema)
  });

  const uploadHandler = async e => {
    setLoadingUpload(true);
    const file = e.target.files[0];
    const bodyFormData = new FormData();
    bodyFormData.append('file', file);
    bodyFormData.append('from', 'testimonial');

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_9___default().post('/api/admin/upload', bodyFormData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          authorization: `Bearer ${userInfo.token}`
        }
      });
      reset(_objectSpread(_objectSpread({}, getValues()), {}, {
        avatar: data.secure_url
      }));
      setLoadingUpload(false);
      enqueueSnackbar('Avatar uploaded successfully', {
        variant: 'success'
      });
    } catch (error) {
      setLoadingUpload(false);
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
        variant: 'error'
      });
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (itemData) {
      reset({
        avatar: itemData === null || itemData === void 0 ? void 0 : itemData.avatar,
        name: itemData === null || itemData === void 0 ? void 0 : itemData.name,
        designation: itemData === null || itemData === void 0 ? void 0 : itemData.designation,
        message: itemData === null || itemData === void 0 ? void 0 : itemData.message
      });
    } else {
      reset(initialValues);
    }
  }, [itemData, reset]);

  const onSubmit = async data => {
    try {
      if (itemId) {
        await axios__WEBPACK_IMPORTED_MODULE_9___default().put(`/api/testimonial/${itemId}`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('Testimonial updated successfully', {
          variant: 'success'
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_9___default().post(`/api/testimonial`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('Testimonial created successfully', {
          variant: 'success'
        });
      }

      props.onClose();
      refreshDataTable();
    } catch (error) {
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
        variant: 'error'
      });
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_modals_HookFormMuiModal__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, _objectSpread(_objectSpread({
    open: true
  }, props), {}, {
    title: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: isEdit ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Edit Testimonial"
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Add a new Testimonial"
      })
    }),
    maxWidth: 'md',
    handleSubmit: handleSubmit(onSubmit),
    actions: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
        onClick: props.onClose
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_button_SubmitButton__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
        isSubmitting: isSubmitting
      })]
    }),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: 5,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        md: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.smallImage,
          variant: "outlined",
          id: "avatar",
          label: "Upload avatar (small image)"
        }, register("avatar")), {}, {
          helperText: (_errors$avatar$messag = (_errors$avatar = errors.avatar) === null || _errors$avatar === void 0 ? void 0 : _errors$avatar.message) !== null && _errors$avatar$messag !== void 0 ? _errors$avatar$messag : null,
          InputProps: {
            readOnly: true
          },
          fullWidth: true
        }))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 6
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 6,
        sx: {
          display: 'flex',
          justifyContent: 'end'
        },
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
          variant: "contained",
          component: "label",
          children: ["Upload avatar", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("input", {
            type: "file",
            onChange: e => uploadHandler(e),
            hidden: true,
            accept: "image/*"
          })]
        }), loadingUpload && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {})]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.name,
          variant: "outlined",
          fullWidth: true,
          id: "name",
          label: "Name"
        }, register("name")), {}, {
          helperText: (_errors$name$message = (_errors$name = errors.name) === null || _errors$name === void 0 ? void 0 : _errors$name.message) !== null && _errors$name$message !== void 0 ? _errors$name$message : null
        }))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.designation,
          variant: "outlined",
          fullWidth: true,
          id: "designation",
          label: "Designation"
        }, register("designation")), {}, {
          helperText: (_errors$designation$m = (_errors$designation = errors.designation) === null || _errors$designation === void 0 ? void 0 : _errors$designation.message) !== null && _errors$designation$m !== void 0 ? _errors$designation$m : null
        }))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.message,
          variant: "outlined",
          fullWidth: true,
          id: "message",
          label: "Message",
          rows: 3,
          multiline: true
        }, register("message")), {}, {
          helperText: (_errors$message$messa = errors === null || errors === void 0 ? void 0 : (_errors$message = errors.message) === null || _errors$message === void 0 ? void 0 : _errors$message.message) !== null && _errors$message$messa !== void 0 ? _errors$message$messa : null
        }))
      })]
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TestimonialAddEditPopup);

/***/ })

};
;