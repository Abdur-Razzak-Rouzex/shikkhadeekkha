"use strict";
exports.id = 4381;
exports.ids = [4381];
exports.modules = {

/***/ 4381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_common_modals_CustomDetailsViewMuiModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2403);
/* harmony import */ var _components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6504);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_error__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9873);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3308);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4562);
/* harmony import */ var _utils_classes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3391);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4010);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_common_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7733);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
const _excluded = ["itemId", "userInfo"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

















const AdmissionInThisCourseDetails = _ref => {
  var _itemData$studentInfo, _itemData$studentInfo2, _itemData$studentInfo3, _itemData$studentInfo4, _itemData$studentInfo5, _itemData$studentInfo6, _itemData$studentInfo7, _itemData$studentInfo8, _itemData$studentInfo9, _itemData$parentsInfo, _itemData$parentsInfo2, _itemData$parentsInfo3, _itemData$parentsInfo4, _itemData$parentsInfo5, _itemData$parentsInfo6, _itemData$parentsInfo7, _itemData$parentsInfo8, _itemData$parentsInfo9, _itemData$academicGua, _itemData$academicGua2, _itemData$academicGua3, _itemData$academicGua4, _itemData$academicGua5, _itemData$otherInfo, _itemData$otherInfo2, _itemData$otherInfo3, _itemData$otherInfo4, _itemData$otherInfo5, _itemData$otherInfo5$, _itemData$otherInfo6, _itemData$otherInfo7, _itemData$otherInfo7$;

  let {
    itemId,
    userInfo
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  const {
    0: itemData,
    1: setItemData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    enqueueSnackbar
  } = (0,notistack__WEBPACK_IMPORTED_MODULE_6__.useSnackbar)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!(userInfo !== null && userInfo !== void 0 && userInfo.name)) {
      router.push('/login');
    }

    const getBanner = async () => {
      try {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_4___default().get(`/api/admission/${itemId}`, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        setItemData(data);
      } catch (error) {
        enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_12__/* .getError */ .b)(error), {
          variant: 'error'
        });
      }
    };

    getBanner();
  }, [itemId]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
    children: itemData && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_modals_CustomDetailsViewMuiModal__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, _objectSpread(_objectSpread({
      open: true
    }, props), {}, {
      title: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          component: 'span',
          variant: 'h5',
          children: "Admission Form details"
        })
      }),
      maxWidth: 'md',
      actions: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
          onClick: props.onClose
        })
      }),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        sx: {
          justifyContent: 'center'
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 12,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
            sx: _utils_classes__WEBPACK_IMPORTED_MODULE_8__/* .default.section */ .Z.section,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.List, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                sx: {
                  justifyContent: 'center'
                },
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  component: "h2",
                  variant: "h2",
                  children: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09B0\u09CD\u09A5\u09C0\u09B0 \u09A4\u09A5\u09CD\u09AF"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09B0\u09CD\u09A5\u09C0\u09B0 \u09A8\u09BE\u09AE  (\u09AC\u09BE\u0982\u09B2\u09BE)",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo = itemData.studentInfo) === null || _itemData$studentInfo === void 0 ? void 0 : _itemData$studentInfo.studentNameBn
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09B0\u09CD\u09A5\u09C0\u09B0 \u09A8\u09BE\u09AE  (\u0987\u0982\u09B0\u09C7\u099C\u09C0)",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo2 = itemData.studentInfo) === null || _itemData$studentInfo2 === void 0 ? void 0 : _itemData$studentInfo2.studentNameEn
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u099C\u09A8\u09CD\u09AE\u09A4\u09BE\u09B0\u09BF\u0996",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo3 = itemData.studentInfo) === null || _itemData$studentInfo3 === void 0 ? void 0 : _itemData$studentInfo3.dateOfBirth
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B6\u09CD\u09B0\u09C7\u09A3\u09C0",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo4 = itemData.studentInfo) === null || _itemData$studentInfo4 === void 0 ? void 0 : _itemData$studentInfo4.studentClass
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE \u09AA\u09CD\u09B0\u09A4\u09BF\u09B7\u09CD\u09A0\u09BE\u09A8\u09C7\u09B0 \u09A8\u09BE\u09AE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo5 = itemData.studentInfo) === null || _itemData$studentInfo5 === void 0 ? void 0 : _itemData$studentInfo5.instituteName
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09B0 \u09AE\u09BE\u09A7\u09CD\u09AF\u09AE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo6 = itemData.studentInfo) === null || _itemData$studentInfo6 === void 0 ? void 0 : _itemData$studentInfo6.educationMedium
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 12,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("img", {
                      src: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo7 = itemData.studentInfo) === null || _itemData$studentInfo7 === void 0 ? void 0 : _itemData$studentInfo7.passportSizePhotoUrl,
                      alt: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo8 = itemData.studentInfo) === null || _itemData$studentInfo8 === void 0 ? void 0 : _itemData$studentInfo8.studentNameBn,
                      height: 300,
                      width: 300,
                      title: itemData === null || itemData === void 0 ? void 0 : (_itemData$studentInfo9 = itemData.studentInfo) === null || _itemData$studentInfo9 === void 0 ? void 0 : _itemData$studentInfo9.studentNameBn
                    })
                  })]
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
            sx: _utils_classes__WEBPACK_IMPORTED_MODULE_8__/* .default.section */ .Z.section,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.List, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                sx: {
                  justifyContent: 'center'
                },
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  component: "h2",
                  variant: "h2",
                  children: "\u09AA\u09BF\u09A4\u09BE\u09AE\u09BE\u09A4\u09BE\u09B0 \u09A4\u09A5\u09CD\u09AF"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AC\u09BE\u09AC\u09BE\u09B0 \u09A8\u09BE\u09AE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo = itemData.parentsInfo) === null || _itemData$parentsInfo === void 0 ? void 0 : _itemData$parentsInfo.fatherName
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AC\u09BE\u09AC\u09BE\u09B0 \u09AA\u09C7\u09B6\u09BE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo2 = itemData.parentsInfo) === null || _itemData$parentsInfo2 === void 0 ? void 0 : _itemData$parentsInfo2.fatherProfession
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AE\u09BE\u09DF\u09C7\u09B0 \u09A8\u09BE\u09AE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo3 = itemData.parentsInfo) === null || _itemData$parentsInfo3 === void 0 ? void 0 : _itemData$parentsInfo3.motherName
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AE\u09BE\u09DF\u09C7\u09B0 \u09AA\u09C7\u09B6\u09BE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo4 = itemData.parentsInfo) === null || _itemData$parentsInfo4 === void 0 ? void 0 : _itemData$parentsInfo4.motherProfession
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u098F\u0995\u09BE\u09A1\u09C7\u09AE\u09BF\u0995 \u0989\u09A6\u09CD\u09A6\u09C7\u09B6\u09CD\u09AF\u09C7 \u0985\u09AD\u09BF\u09AD\u09BE\u09AC\u0995\u09C7\u09B0 \u09AB\u09CB\u09A8 \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo5 = itemData.parentsInfo) === null || _itemData$parentsInfo5 === void 0 ? void 0 : _itemData$parentsInfo5.parentsDirectContact
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AA\u09BF\u09A4\u09BE\u09AE\u09BE\u09A4\u09BE\u09B0 Whatsapp \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo6 = itemData.parentsInfo) === null || _itemData$parentsInfo6 === void 0 ? void 0 : _itemData$parentsInfo6.parentsWhatsappNumber
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AE\u09BE/\u09AC\u09BE\u09AC\u09BE\u09B0 \u0987 - \u09AE\u09C7\u0987\u09B2",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo7 = itemData.parentsInfo) === null || _itemData$parentsInfo7 === void 0 ? void 0 : _itemData$parentsInfo7.parentsEmail
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u098F\u0995\u09BE\u09A1\u09C7\u09AE\u09BF\u0995 \u0989\u09A6\u09CD\u09A6\u09C7\u09B6\u09CD\u09AF\u09C7 \u09AF\u09BF\u09A8\u09BF \u09AF\u09CB\u0997\u09BE\u09AF\u09CB\u0997 \u0995\u09B0\u09AC\u09C7\u09A8",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo8 = itemData.parentsInfo) === null || _itemData$parentsInfo8 === void 0 ? void 0 : _itemData$parentsInfo8.academicallyResponsiblePerson
                    })
                  })]
                })
              })]
            })
          }), (itemData === null || itemData === void 0 ? void 0 : (_itemData$parentsInfo9 = itemData.parentsInfo) === null || _itemData$parentsInfo9 === void 0 ? void 0 : _itemData$parentsInfo9.academicallyResponsiblePerson) === _components_common_constants__WEBPACK_IMPORTED_MODULE_10__/* .PARENTS_TYPE[3].name */ .GA[3].name && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
            sx: _utils_classes__WEBPACK_IMPORTED_MODULE_8__/* .default.section */ .Z.section,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.List, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                sx: {
                  justifyContent: 'center'
                },
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  component: "h2",
                  variant: "h2",
                  children: "\u098F\u0995\u09BE\u09A1\u09C7\u09AE\u09BF\u0995 \u0985\u09AD\u09BF\u09AD\u09BE\u09AC\u0995"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u0985\u09AD\u09BF\u09AD\u09BE\u09AC\u0995\u09C7\u09B0 \u09A8\u09BE\u09AE",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$academicGua = itemData.academicGuardianInfo) === null || _itemData$academicGua === void 0 ? void 0 : _itemData$academicGua.guardianName
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B8\u09AE\u09CD\u09AA\u09B0\u09CD\u0995",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$academicGua2 = itemData.academicGuardianInfo) === null || _itemData$academicGua2 === void 0 ? void 0 : _itemData$academicGua2.relation
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09AE\u09CB\u09AC\u09BE\u0987\u09B2 \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$academicGua3 = itemData.academicGuardianInfo) === null || _itemData$academicGua3 === void 0 ? void 0 : _itemData$academicGua3.guardianMobileNumber
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B9\u09CB\u09AF\u09BC\u09BE\u099F\u09B8\u0985\u09CD\u09AF\u09BE\u09AA \u09A8\u09BE\u09AE\u09CD\u09AC\u09BE\u09B0",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$academicGua4 = itemData.academicGuardianInfo) === null || _itemData$academicGua4 === void 0 ? void 0 : _itemData$academicGua4.guardianWhatsappNumber
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u0987\u09AE\u09C7\u0987\u09B2",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$academicGua5 = itemData.academicGuardianInfo) === null || _itemData$academicGua5 === void 0 ? void 0 : _itemData$academicGua5.guardianEmail
                    })
                  })]
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
            sx: _utils_classes__WEBPACK_IMPORTED_MODULE_8__/* .default.section */ .Z.section,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.List, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                sx: {
                  justifyContent: 'center'
                },
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                  component: "h2",
                  variant: "h2",
                  children: "\u0985\u09A8\u09CD\u09AF\u09BE\u09A8\u09CD\u09AF \u09A4\u09A5\u09CD\u09AF"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                  container: true,
                  spacing: 2,
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u0995\u09CB\u09B0\u09CD\u09B8 \u09B8\u09BF\u09B2\u09C7\u0995\u09CD\u099F",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo = itemData.otherInfo) === null || _itemData$otherInfo === void 0 ? void 0 : _itemData$otherInfo.selectedCourse
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09B0\u09CD\u09A5\u09C0\u09B0 \u0997\u09CD\u09B0\u09C1\u09AA\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF Whatsapp \u09A8\u09AE\u09CD\u09AC\u09B0",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo2 = itemData.otherInfo) === null || _itemData$otherInfo2 === void 0 ? void 0 : _itemData$otherInfo2.studentGroupWhatsappNo
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "Google \u0995\u09CD\u09B2\u09BE\u09B8\u09B0\u09C1\u09AE\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF \u09B6\u09BF\u0995\u09CD\u09B7\u09BE\u09B0\u09CD\u09A5\u09C0\u09B0 \u099C\u09BF\u09AE\u09C7\u0987\u09B2 \u0986\u0987\u09A1\u09BF",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo3 = itemData.otherInfo) === null || _itemData$otherInfo3 === void 0 ? void 0 : _itemData$otherInfo3.studentGmailId
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .default */ .ZP, {
                      label: "\u0986\u09AC\u09BE\u09B8\u09BF\u0995 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE (\u0995\u09C1\u09B0\u09BF\u09AF\u09BC\u09BE\u09B0\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF)",
                      value: itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo4 = itemData.otherInfo) === null || _itemData$otherInfo4 === void 0 ? void 0 : _itemData$otherInfo4.residentForCourier
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 12,
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .StyledGrid */ .HF, {
                      item: true,
                      xs: 12,
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_9___default()), {
                        className: _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === null || _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === void 0 ? void 0 : _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses.label */ .NF.label,
                        children: "\u09B2\u09BE\u0987\u09AD \u0995\u09CD\u09B2\u09BE\u09B8\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF \u09AF\u09C7 \u09A7\u09B0\u09A8\u09C7\u09B0 \u0987\u09B2\u09C7\u0995\u099F\u09CD\u09B0\u09A8\u09BF\u0995 \u09AE\u09A1\u09BF\u0989\u09B2 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09BE \u09B9\u09AC\u09C7"
                      }), itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo5 = itemData.otherInfo) === null || _itemData$otherInfo5 === void 0 ? void 0 : (_itemData$otherInfo5$ = _itemData$otherInfo5.typeOfElectronicsToBeUsedInLiveClass) === null || _itemData$otherInfo5$ === void 0 ? void 0 : _itemData$otherInfo5$.map((device, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)("div", {
                        className: _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === null || _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === void 0 ? void 0 : _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses.inputView */ .NF.inputView,
                        children: ["\u2003", `${index + 1}  :  ${device}`]
                      }, device))]
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 12,
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .StyledGrid */ .HF, {
                      item: true,
                      xs: 12,
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_9___default()), {
                        className: _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === null || _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === void 0 ? void 0 : _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses.label */ .NF.label,
                        children: "\u09B8\u09B9-\u09AA\u09BE\u09A0\u09CD\u09AF\u0995\u09CD\u09B0\u09AE\u09BF\u0995 \u0995\u09CD\u09B0\u09BF\u09AF\u09BC\u09BE\u0995\u09B2\u09BE\u09AA \u09AF\u09C7\u0997\u09C1\u09B2\u09CB\u09A4\u09C7 \u0986\u09AA\u09A8\u09BF \u09AF\u09CB\u0997 \u09A6\u09BF\u09A4\u09C7 \u099A\u09BE\u09A8"
                      }), typeof (itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo6 = itemData.otherInfo) === null || _itemData$otherInfo6 === void 0 ? void 0 : _itemData$otherInfo6.coCurricularActivities) === 'undefined' ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        sx: {
                          textAlign: 'center'
                        },
                        mt: 3,
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                          className: _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === null || _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === void 0 ? void 0 : _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses.inputView */ .NF.inputView,
                          children: "\u2003\u0995\u09CB\u09A8 \u0995\u09BF\u099B\u09C1\u0987 \u09AF\u09CB\u0997 \u0995\u09B0\u09C7\u09A8\u09A8\u09BF"
                        })
                      }) : itemData === null || itemData === void 0 ? void 0 : (_itemData$otherInfo7 = itemData.otherInfo) === null || _itemData$otherInfo7 === void 0 ? void 0 : (_itemData$otherInfo7$ = _itemData$otherInfo7.coCurricularActivities) === null || _itemData$otherInfo7$ === void 0 ? void 0 : _itemData$otherInfo7$.map((coCurriculm, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        className: _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === null || _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses */ .NF === void 0 ? void 0 : _components_common_elements_DetailsInputView__WEBPACK_IMPORTED_MODULE_7__/* .styleClasses.inputView */ .NF.inputView,
                        children: ["\u2003", `${index + 1}  :  ${coCurriculm}`]
                      }, coCurriculm))]
                    })
                  })]
                })
              })]
            })
          })]
        })
      })
    }))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdmissionInThisCourseDetails);

/***/ })

};
;