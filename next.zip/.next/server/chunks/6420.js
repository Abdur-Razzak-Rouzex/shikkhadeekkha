"use strict";
exports.id = 6420;
exports.ids = [6420];
exports.modules = {

/***/ 6420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};

async function connect() {
  if (connection.isConnected) {
    console.log('already connected');
    return;
  }

  if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections.length) > 0) {
    connection.isConnected = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().connections[0].readyState);

    if (connection.isConnected === 1) {
      console.log('use previous connection');
      return;
    }

    await mongoose__WEBPACK_IMPORTED_MODULE_0___default().disconnect();
  }

  const dbPath = 'mongodb+srv://rouzexsd:1663RZXsd@cluster0.5u1vd.mongodb.net/sddb?retryWrites=true&w=majority';
  /*const db = await mongoose.connect(process.env.MONGODB_URI, {*/

  const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(dbPath, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });
  console.log('new connection');
  connection.isConnected = db.connections[0].readyState;
}

async function disconnect() {
  if (connection.isConnected) {
    if (true) {
      await mongoose__WEBPACK_IMPORTED_MODULE_0___default().disconnect();
      connection.isConnected = false;
    } else {}
  }
}

function convertDocToObj(doc) {
  doc._id = doc === null || doc === void 0 ? void 0 : doc._id.toString();
  doc.createdAt = doc === null || doc === void 0 ? void 0 : doc.createdAt.toString();
  doc.updatedAt = doc === null || doc === void 0 ? void 0 : doc.updatedAt.toString();

  if (doc !== null && doc !== void 0 && doc.category) {
    var _doc$category, _doc$category$_id;

    doc.category._id = doc === null || doc === void 0 ? void 0 : (_doc$category = doc.category) === null || _doc$category === void 0 ? void 0 : (_doc$category$_id = _doc$category._id) === null || _doc$category$_id === void 0 ? void 0 : _doc$category$_id.toString();
  }

  return doc;
}

const db = {
  connect,
  disconnect,
  convertDocToObj
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);

/***/ })

};
;