"use strict";
exports.id = 7733;
exports.ids = [7733];
exports.modules = {

/***/ 7733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EX": () => (/* binding */ muiDataTableOptions),
/* harmony export */   "Ty": () => (/* binding */ LANGUAGE_MEDIUM),
/* harmony export */   "er": () => (/* binding */ STUDENT_CLASS),
/* harmony export */   "CI": () => (/* binding */ EDUCATION_MEDIUM),
/* harmony export */   "GA": () => (/* binding */ PARENTS_TYPE),
/* harmony export */   "WO": () => (/* binding */ DEVICE_TYPES),
/* harmony export */   "U_": () => (/* binding */ CO_CURRICULAR_ACTIVITIES),
/* harmony export */   "FS": () => (/* binding */ MOBILE_NUMBER_REGEX),
/* harmony export */   "R3": () => (/* binding */ COURSE_TYPE)
/* harmony export */ });
/* unused harmony export EMAIL_REGEX */
const muiDataTableOptions = {
  filterType: 'dropdown',
  serverSide: true,
  selectableRowsHideCheckboxes: true,
  enableNestedDataAccess: '.'
};
const LANGUAGE_MEDIUM = ['bangla', 'english', 'both'];
const STUDENT_CLASS = [{
  name: 'five',
  title: 'পঞ্চম'
}, {
  name: 'six',
  title: 'ষষ্ঠ'
}, {
  name: 'seven',
  title: 'সপ্তম'
}, {
  name: 'eight',
  title: 'অষ্টম'
}, {
  name: 'nine',
  title: 'নবম'
}, {
  name: 'ten',
  title: 'দশম'
}, {
  name: 'eleven',
  title: 'একাদশ'
}, {
  name: 'twelve',
  title: 'দ্বাদশ'
}];
const EDUCATION_MEDIUM = [{
  name: 'bangla',
  title: 'বাংলা'
}, {
  name: 'english',
  title: 'ইংরেজী'
}];
const PARENTS_TYPE = [{
  name: 'father',
  title: 'বাবা'
}, {
  name: 'mother',
  title: 'মা'
}, {
  name: 'both',
  title: 'উভয়ই'
}, {
  name: 'other',
  title: 'অন্য কেউ'
}];
const DEVICE_TYPES = ['Phone [Have option to attach additional camera ]', 'Phone [Do not have any option to attach additional camera ]', 'Tablet [Have option to attach additional camera ]', 'Tablet [Do not have any option to attach additional camera ]', 'Desktop', 'Laptop', 'Single board PC', 'Other [Have option to attach additional camera ]', 'Other [Do not have any option to attach additional camera ]'];
const CO_CURRICULAR_ACTIVITIES = ['Chess', '16 Beads [ষোল গুটি]', 'Story writing', 'গল্প লেখা', 'Drawings', 'Debate', 'Extempore Speech', 'Assignment Compettion', 'Digital Art'];
const MOBILE_NUMBER_REGEX = new RegExp('^(?:\\+88|88)?(01[3-9]\\d{8})$');
const EMAIL_REGEX = (/* unused pure expression or super */ null && (new RegExp('(<|^)[a-z\\d.]+([a-z\\d.\\s_-]{0,30})+@(?:[a-z\\d]+\\.)+([a-z]{2,})(>|$)')));
const COURSE_TYPE = 'course';

/***/ })

};
;