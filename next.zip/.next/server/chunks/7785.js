"use strict";
exports.id = 7785;
exports.ids = [7785];
exports.modules = {

/***/ 7785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3308);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_error__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9873);
/* harmony import */ var _components_common_modals_HookFormMuiModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(214);
/* harmony import */ var _components_common_button_SubmitButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7324);
/* harmony import */ var _components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6504);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_Store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2236);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
const _excluded = ["itemId", "refreshDataTable"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

















const initialValues = {
  smallImage: '',
  largeImage: '',
  title: '',
  shortDescription: '',
  isFlipBook: false,
  flipBookLink: '',
  contentBody: ''
};

const WhyChooseUsAddEditPopup = _ref => {
  var _errors$smallImage$me, _errors$smallImage, _errors$title$message, _errors$title, _errors$shortDescript, _errors$shortDescript2, _errors$flipBookLink$, _errors$flipBookLink, _errors$contentBody$m, _errors$contentBody, _errors$largeImage$me, _errors$largeImage;

  let {
    itemId,
    refreshDataTable
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    enqueueSnackbar
  } = (0,notistack__WEBPACK_IMPORTED_MODULE_4__.useSnackbar)();
  const isEdit = itemId != null;
  const {
    0: loadingUpload,
    1: setLoadingUpload
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
  const {
    state
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_utils_Store__WEBPACK_IMPORTED_MODULE_10__/* .Store */ .y);
  const {
    userInfo
  } = state;
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
  const {
    0: itemData,
    1: setItemData
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(initialValues);
  const {
    0: isFlipBookChecked,
    1: setIsFlipBookChecked
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (!(userInfo !== null && userInfo !== void 0 && userInfo.name)) {
      router.push('/login');
    }

    const getWhyChooseUs = async () => {
      try {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_9___default().get(`/api/why-choose-us/${itemId}`, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        setItemData(data);
      } catch (error) {
        enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
          variant: 'error'
        });
      }
    };

    if (itemId) {
      getWhyChooseUs();
    }
  }, [itemId]);
  const validationSchema = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    return yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      smallImage: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Small Image"),
      title: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Title"),
      shortDescription: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Short Description"),
      isFlipBook: yup__WEBPACK_IMPORTED_MODULE_0__.boolean().required().label("Is FlipBook"),
      flipBookLink: yup__WEBPACK_IMPORTED_MODULE_0__.mixed().label("FlipBook link").when('isFlipBook', {
        is: true,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
      }),
      contentBody: yup__WEBPACK_IMPORTED_MODULE_0__.mixed().label("Content Body").when('isFlipBook', {
        is: false,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
      }),
      largeImage: yup__WEBPACK_IMPORTED_MODULE_0__.mixed().label("Large Image").when('isFlipBook', {
        is: false,
        then: yup__WEBPACK_IMPORTED_MODULE_0__.string().required()
      })
    });
  }, []);
  const {
    register,
    reset,
    handleSubmit,
    getValues,
    formState: {
      errors,
      isSubmitting
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(validationSchema)
  });

  const uploadHandler = async (e, imageSize = 'image') => {
    setLoadingUpload(true);
    const file = e.target.files[0];
    const bodyFormData = new FormData();
    bodyFormData.append('file', file);
    bodyFormData.append('from', 'whyChooseUs');

    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_9___default().post('/api/admin/upload', bodyFormData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          authorization: `Bearer ${userInfo.token}`
        }
      });

      if (imageSize === 'smallImage') {
        reset(_objectSpread(_objectSpread({}, getValues()), {}, {
          smallImage: data.secure_url
        }));
      } else {
        reset(_objectSpread(_objectSpread({}, getValues()), {}, {
          largeImage: data.secure_url
        }));
      }

      setLoadingUpload(false);
      enqueueSnackbar('Image for "Why choose Us" section uploaded successfully', {
        variant: 'success'
      });
    } catch (error) {
      setLoadingUpload(false);
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
        variant: 'error'
      });
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (itemData) {
      reset({
        smallImage: itemData === null || itemData === void 0 ? void 0 : itemData.smallImage,
        largeImage: itemData === null || itemData === void 0 ? void 0 : itemData.largeImage,
        title: itemData === null || itemData === void 0 ? void 0 : itemData.title,
        shortDescription: itemData === null || itemData === void 0 ? void 0 : itemData.shortDescription,
        isFlipBook: itemData === null || itemData === void 0 ? void 0 : itemData.isFlipBook,
        flipBookLink: itemData === null || itemData === void 0 ? void 0 : itemData.flipBookLink,
        contentBody: itemData === null || itemData === void 0 ? void 0 : itemData.contentBody
      });
      setIsFlipBookChecked(itemData === null || itemData === void 0 ? void 0 : itemData.isFlipBook);
    } else {
      reset(initialValues);
    }
  }, [itemData, reset]);

  const onSubmit = async data => {
    /*console.log('why choose us add edit submitted data: ', data);*/
    try {
      if (itemId) {
        await axios__WEBPACK_IMPORTED_MODULE_9___default().put(`/api/why-choose-us/${itemId}`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('"Why Choose Us" updated successfully', {
          variant: 'success'
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_9___default().post(`/api/why-choose-us`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('"Why Choose Us" created successfully', {
          variant: 'success'
        });
      }

      props.onClose();
      refreshDataTable();
    } catch (error) {
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
        variant: 'error'
      });
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_modals_HookFormMuiModal__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, _objectSpread(_objectSpread({
    open: true
  }, props), {}, {
    title: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: isEdit ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Edit Why Choose Us"
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Add a new Why Choose Us"
      })
    }),
    maxWidth: 'md',
    handleSubmit: handleSubmit(onSubmit),
    actions: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
        onClick: props.onClose
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_button_SubmitButton__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
        isSubmitting: isSubmitting
      })]
    }),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: 5,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        md: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.smallImage,
          variant: "outlined",
          id: "smallImage",
          label: "Upload small image for why choose us section"
        }, register("smallImage")), {}, {
          helperText: (_errors$smallImage$me = (_errors$smallImage = errors.smallImage) === null || _errors$smallImage === void 0 ? void 0 : _errors$smallImage.message) !== null && _errors$smallImage$me !== void 0 ? _errors$smallImage$me : null,
          InputProps: {
            readOnly: true
          },
          fullWidth: true
        }))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 6
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 6,
        sx: {
          display: 'flex',
          justifyContent: 'end'
        },
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
          variant: "contained",
          component: "label",
          children: ["Upload small image", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("input", {
            type: "file",
            onChange: e => uploadHandler(e, 'smallImage'),
            hidden: true,
            accept: "image/*"
          })]
        }), loadingUpload && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {})]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.title,
          variant: "outlined",
          fullWidth: true,
          id: "title",
          label: "Title"
        }, register("title")), {}, {
          helperText: (_errors$title$message = (_errors$title = errors.title) === null || _errors$title === void 0 ? void 0 : _errors$title.message) !== null && _errors$title$message !== void 0 ? _errors$title$message : null
        }))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.shortDescription,
          variant: "outlined",
          fullWidth: true,
          id: "shortDescription",
          label: "Write a short Description",
          rows: 2,
          multiline: true
        }, register("shortDescription")), {}, {
          helperText: (_errors$shortDescript = (_errors$shortDescript2 = errors.shortDescription) === null || _errors$shortDescript2 === void 0 ? void 0 : _errors$shortDescript2.message) !== null && _errors$shortDescript !== void 0 ? _errors$shortDescript : null
        }))
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        sx: {
          display: 'flex'
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Checkbox, _objectSpread(_objectSpread({
          id: "isFlipBook",
          color: 'primary',
          checked: isFlipBookChecked
        }, register("isFlipBook")), {}, {
          onChange: () => setIsFlipBookChecked(prevState => !prevState)
        })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
          sx: {
            paddingTop: '10px'
          },
          children: "Is Flip Book"
        })]
      }), isFlipBookChecked && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.flipBookLink,
          variant: "outlined",
          fullWidth: true,
          id: "flipBookLink",
          label: "Insert the flip book link"
        }, register("flipBookLink")), {}, {
          helperText: (_errors$flipBookLink$ = (_errors$flipBookLink = errors.flipBookLink) === null || _errors$flipBookLink === void 0 ? void 0 : _errors$flipBookLink.message) !== null && _errors$flipBookLink$ !== void 0 ? _errors$flipBookLink$ : null
        }))
      }), !isFlipBookChecked && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
            error: !!errors.contentBody,
            variant: "outlined",
            fullWidth: true,
            id: "contentBody",
            label: "Write the content body",
            rows: 10,
            multiline: true
          }, register("contentBody")), {}, {
            helperText: (_errors$contentBody$m = (_errors$contentBody = errors.contentBody) === null || _errors$contentBody === void 0 ? void 0 : _errors$contentBody.message) !== null && _errors$contentBody$m !== void 0 ? _errors$contentBody$m : null
          }))
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 12,
          md: 12,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
            error: !!errors.largeImage,
            variant: "outlined",
            id: "largeImage",
            label: "Upload large image for about us details page"
          }, register("largeImage")), {}, {
            helperText: (_errors$largeImage$me = (_errors$largeImage = errors.largeImage) === null || _errors$largeImage === void 0 ? void 0 : _errors$largeImage.message) !== null && _errors$largeImage$me !== void 0 ? _errors$largeImage$me : null,
            InputProps: {
              readOnly: true
            },
            fullWidth: true
          }))
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 6
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
          item: true,
          xs: 6,
          sx: {
            display: 'flex',
            justifyContent: 'end'
          },
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
            variant: "contained",
            component: "label",
            children: ["Upload large image", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("input", {
              type: "file",
              onChange: uploadHandler,
              hidden: true,
              accept: "image/*"
            })]
          }), loadingUpload && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {})]
        })]
      })]
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhyChooseUsAddEditPopup);

/***/ })

};
;