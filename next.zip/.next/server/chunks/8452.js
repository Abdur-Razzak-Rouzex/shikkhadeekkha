"use strict";
exports.id = 8452;
exports.ids = [8452];
exports.modules = {

/***/ 8452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ courses_CourseAddEditPopup)
});

// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(9440);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__(2662);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "notistack"
var external_notistack_ = __webpack_require__(3308);
// EXTERNAL MODULE: external "@hookform/resolvers/yup"
var yup_ = __webpack_require__(2166);
// EXTERNAL MODULE: ./utils/error.js
var utils_error = __webpack_require__(9873);
// EXTERNAL MODULE: ./components/common/modals/HookFormMuiModal.js
var HookFormMuiModal = __webpack_require__(214);
// EXTERNAL MODULE: ./components/common/button/SubmitButton.js
var SubmitButton = __webpack_require__(7324);
// EXTERNAL MODULE: ./components/common/button/CancelButton.js
var CancelButton = __webpack_require__(6504);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./utils/Store.js
var Store = __webpack_require__(2236);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./components/common/FilePondUploader.js
var FilePondUploader = __webpack_require__(180);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/common/CkEditor.js



function CkEditor({
  getEditorData,
  defaultData = ''
}) {
  let editorRef = (0,external_react_.useRef)();
  const {
    CKEditor,
    ClassicEditor
  } = editorRef.current || {}; // if it don't find any document then it will be an empty object

  let {
    0: loaded,
    1: setLoaded
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    editorRef.current = {
      CKEditor: __webpack_require__(3920).CKEditor,
      // v3+
      ClassicEditor: __webpack_require__(4717)
    };
    setLoaded(true);
  }, []); // run on mounting

  if (loaded) {
    return /*#__PURE__*/jsx_runtime_.jsx(CKEditor, {
      editor: ClassicEditor,
      data: defaultData,
      onReady: editor => {
        // You can store the "editor" and use when it is needed.
        console.log("Editor is ready to use!", editor);
      },
      onChange: (event, editor) => {
        // do something when editor's content changed
        const data = editor.getData();
        getEditorData(data);
        console.log({
          event,
          editor,
          data
        });
      },
      onBlur: (event, editor) => {
        console.log("Blur.", editor);
      },
      onFocus: (event, editor) => {
        console.log("Focus.", editor);
      },
      config: {
        placeholder: 'Start writing....'
      }
    });
  } else {
    return /*#__PURE__*/jsx_runtime_.jsx("h2", {
      children: " Editor is loading "
    });
  }
}

/* harmony default export */ const common_CkEditor = (CkEditor);
// EXTERNAL MODULE: external "@mui/material/FormGroup"
var FormGroup_ = __webpack_require__(6546);
var FormGroup_default = /*#__PURE__*/__webpack_require__.n(FormGroup_);
// EXTERNAL MODULE: external "@mui/material/FormControlLabel"
var FormControlLabel_ = __webpack_require__(3877);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_);
// EXTERNAL MODULE: external "@mui/material/Checkbox"
var Checkbox_ = __webpack_require__(759);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_);
;// CONCATENATED MODULE: ./components/common/CustomCheckBox.js





function CustomCheckBox({
  checked,
  handleChange,
  label,
  color = 'success'
}) {
  return /*#__PURE__*/jsx_runtime_.jsx((FormGroup_default()), {
    children: /*#__PURE__*/jsx_runtime_.jsx((FormControlLabel_default()), {
      control: /*#__PURE__*/jsx_runtime_.jsx((Checkbox_default()), {
        checked: checked,
        onChange: handleChange,
        inputProps: {
          'aria-label': 'controlled'
        },
        color: color
      }),
      label: label
    })
  });
}
// EXTERNAL MODULE: ./components/common/constants.js
var constants = __webpack_require__(7733);
// EXTERNAL MODULE: external "@mui/material/Radio"
var Radio_ = __webpack_require__(8454);
var Radio_default = /*#__PURE__*/__webpack_require__.n(Radio_);
// EXTERNAL MODULE: external "@mui/material/RadioGroup"
var RadioGroup_ = __webpack_require__(1354);
var RadioGroup_default = /*#__PURE__*/__webpack_require__.n(RadioGroup_);
// EXTERNAL MODULE: external "@mui/material/FormControl"
var FormControl_ = __webpack_require__(3581);
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl_);
// EXTERNAL MODULE: external "@mui/material/FormLabel"
var FormLabel_ = __webpack_require__(4010);
var FormLabel_default = /*#__PURE__*/__webpack_require__.n(FormLabel_);
;// CONCATENATED MODULE: ./components/common/CustomRadioButton.js








function CustomRadioButton({
  label,
  row = true,
  value,
  handleChange,
  options
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)((FormControl_default()), {
    children: [/*#__PURE__*/jsx_runtime_.jsx((FormLabel_default()), {
      id: "demo-controlled-radio-buttons-group",
      children: label
    }), /*#__PURE__*/jsx_runtime_.jsx((RadioGroup_default()), {
      row: row,
      "aria-labelledby": "demo-controlled-radio-buttons-group",
      name: "controlled-radio-buttons-group",
      value: value || '',
      onChange: handleChange,
      color: "success",
      children: options.map(option => /*#__PURE__*/jsx_runtime_.jsx((FormControlLabel_default()), {
        value: option,
        control: /*#__PURE__*/jsx_runtime_.jsx((Radio_default()), {}),
        label: option
      }, option))
    })]
  });
}
;// CONCATENATED MODULE: ./pages/admin/courses/CourseAddEditPopup.js
const _excluded = ["itemId", "refreshDataTable"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






















const initialValues = {
  name: '',
  type: 'course',
  slug: '',
  category: '',
  subCategory: '',
  image: '',
  price: 0,
  brand: 'general',
  languageMedium: constants/* LANGUAGE_MEDIUM.0 */.Ty[0],
  isFeatured: false,
  isOffered: false,
  offerInPercentage: 0,
  docStatus: true,
  description: ''
};

const CourseAddEditPopup = _ref => {
  var _errors$name$message, _errors$name, _errors$slug$message, _errors$slug, _errors$category$mess, _errors$category, _errors$subCategory$m, _errors$subCategory, _errors$price$message, _errors$price, _errors$offerInPercen, _errors$offerInPercen2;

  let {
    itemId,
    refreshDataTable
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    enqueueSnackbar
  } = (0,external_notistack_.useSnackbar)();
  const isEdit = itemId != null;
  const {
    state
  } = (0,external_react_.useContext)(Store/* Store */.y);
  const {
    userInfo
  } = state;
  const router = (0,router_.useRouter)();
  const {
    0: itemData,
    1: setItemData
  } = (0,external_react_.useState)(initialValues);
  const {
    0: categories,
    1: setCategories
  } = (0,external_react_.useState)([]);
  const {
    0: subCategories,
    1: setSubCategories
  } = (0,external_react_.useState)([]);
  const {
    0: category,
    1: setCategory
  } = (0,external_react_.useState)('');
  const {
    0: subcategory,
    1: setSubcategory
  } = (0,external_react_.useState)('');
  const {
    0: isFeaturedValue,
    1: setIsFeaturedValue
  } = (0,external_react_.useState)(false);
  const {
    0: isOfferedValue,
    1: setIsOfferedValue
  } = (0,external_react_.useState)(false);
  const {
    0: docStatusValue,
    1: setDocStatusValue
  } = (0,external_react_.useState)(true);
  const {
    0: languageMediumValue,
    1: setLanguageMediumValue
  } = (0,external_react_.useState)(constants/* LANGUAGE_MEDIUM.0 */.Ty[0]);
  (0,external_react_.useEffect)(() => {
    if (!(userInfo !== null && userInfo !== void 0 && userInfo.name)) {
      router.push('/login');
    }

    const getCourse = async () => {
      try {
        const {
          data
        } = await external_axios_default().get(`/api/course/${itemId}`);
        setItemData(data);
      } catch (error) {
        enqueueSnackbar((0,utils_error/* getError */.b)(error), {
          variant: 'error'
        });
      }
    };

    const getCategories = async () => {
      try {
        const {
          data
        } = await external_axios_default().get('/api/category');
        setCategories(data);
      } catch (e) {
        enqueueSnackbar((0,utils_error/* getError */.b)(e), {
          variant: 'error'
        });
      }
    };

    getCategories();

    if (itemId) {
      getCourse();
    }
  }, [itemId]);
  const validationSchema = (0,external_react_.useMemo)(() => {
    return external_yup_.object().shape({
      name: external_yup_.string().required().label("Course Name"),
      type: external_yup_.string().default('course'),
      brand: external_yup_.string().default('general'),
      slug: external_yup_.string().required().label("Course Slug"),
      category: external_yup_.string().required().label("Category"),
      subCategory: external_yup_.string().label("Sub-category"),
      image: external_yup_.string().required().label("Course Image"),
      price: external_yup_.number().required().label("Course Fee"),
      languageMedium: external_yup_.string().required().label("Language Medium").default('bangla'),
      description: external_yup_.string().required().label("Course Description"),
      isFeatured: external_yup_.boolean().required().label("Is Featured").default(false),
      isOffered: external_yup_.boolean().required().label("Is Offered").default(false),
      offerInPercentage: external_yup_.mixed().label("Offer Price In percentage").when('isOffered', {
        is: true,
        then: external_yup_.number().required()
      }),
      docStatus: external_yup_.boolean().required().label("Status").default(true)
    });
  }, []);
  const {
    register,
    reset,
    handleSubmit,
    setValue,
    formState: {
      errors,
      isSubmitting
    }
  } = (0,external_react_hook_form_.useForm)({
    resolver: (0,yup_.yupResolver)(validationSchema)
  });
  (0,external_react_.useEffect)(() => {
    if (itemData) {
      var _itemData$category;

      reset({
        name: itemData === null || itemData === void 0 ? void 0 : itemData.name,
        type: itemData === null || itemData === void 0 ? void 0 : itemData.type,
        slug: itemData === null || itemData === void 0 ? void 0 : itemData.slug,
        category: itemData === null || itemData === void 0 ? void 0 : itemData.category,
        subCategory: itemData === null || itemData === void 0 ? void 0 : itemData.subCategory,
        image: itemData === null || itemData === void 0 ? void 0 : itemData.image,
        brand: itemData === null || itemData === void 0 ? void 0 : itemData.brand,
        price: itemData === null || itemData === void 0 ? void 0 : itemData.price,
        languageMedium: itemData === null || itemData === void 0 ? void 0 : itemData.languageMedium,
        offerInPercentage: itemData === null || itemData === void 0 ? void 0 : itemData.offerInPercentage,
        description: itemData === null || itemData === void 0 ? void 0 : itemData.description,
        isFeatured: itemData === null || itemData === void 0 ? void 0 : itemData.isFeatured,
        isOffered: itemData === null || itemData === void 0 ? void 0 : itemData.isOffered,
        docStatus: itemData === null || itemData === void 0 ? void 0 : itemData.docStatus
      });
      setCategory(itemData === null || itemData === void 0 ? void 0 : (_itemData$category = itemData.category) === null || _itemData$category === void 0 ? void 0 : _itemData$category._id);
      setSubcategory(itemData === null || itemData === void 0 ? void 0 : itemData.subCategory);
      setIsFeaturedValue(itemData === null || itemData === void 0 ? void 0 : itemData.isFeatured);
      setIsOfferedValue(itemData === null || itemData === void 0 ? void 0 : itemData.isOffered);
      setDocStatusValue(itemData === null || itemData === void 0 ? void 0 : itemData.docStatus);
    } else {
      reset(initialValues);
    }
  }, [itemData]);

  const getSecureUrl = secureUrl => {
    setValue('image', secureUrl);
  };

  const handleCategoryChange = event => {
    var _categories$cat;

    setValue('category', event.target.value);
    setCategory(event.target.value);
    const cat = categories.findIndex(cat => cat._id === event.target.value);
    setSubCategories((_categories$cat = categories[cat]) === null || _categories$cat === void 0 ? void 0 : _categories$cat.subCategory);
  };

  const handleSubcategoryChange = event => {
    setValue('subCategory', event.target.value);
    setSubcategory(event.target.value);
  };

  const getEditorData = data => {
    setValue('description', data);
  };

  const handleIsFeatured = event => {
    setIsFeaturedValue(event.target.checked);
    setValue('isFeatured', event.target.checked);
  };

  const handleIsOffered = event => {
    setIsOfferedValue(event.target.checked);
    setValue('isOffered', event.target.checked);
  };

  const handleDocStatusChange = event => {
    setDocStatusValue(event.target.checked);
    setValue('docStatus', event.target.checked);
  };

  const handleLanguageChange = event => {
    setLanguageMediumValue(event.target.value);
    setValue('languageMedium', event.target.value);
  };

  const onSubmit = async data => {
    try {
      if (itemId) {
        await external_axios_default().put(`/api/course/${itemId}`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('Course updated successfully', {
          variant: 'success'
        });
      } else {
        await external_axios_default().post(`/api/course`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('Course created successfully', {
          variant: 'success'
        });
      }

      props.onClose();
      refreshDataTable();
    } catch (error) {
      enqueueSnackbar((0,utils_error/* getError */.b)(error), {
        variant: 'error'
      });
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx(HookFormMuiModal/* default */.Z, _objectSpread(_objectSpread({
    open: true
  }, props), {}, {
    title: /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: isEdit ? /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Edit Course"
      }) : /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Add a new Course"
      })
    }),
    maxWidth: 'md',
    handleSubmit: handleSubmit(onSubmit),
    actions: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(CancelButton/* default */.Z, {
        onClick: props.onClose
      }), /*#__PURE__*/jsx_runtime_.jsx(SubmitButton/* default */.Z, {
        isSubmitting: isSubmitting
      })]
    }),
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
      container: true,
      spacing: 5,
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.TextField, _objectSpread(_objectSpread({
          required: true,
          error: !!errors.name,
          variant: "outlined",
          fullWidth: true,
          id: "name",
          label: "Course Name"
        }, register("name")), {}, {
          helperText: (_errors$name$message = (_errors$name = errors.name) === null || _errors$name === void 0 ? void 0 : _errors$name.message) !== null && _errors$name$message !== void 0 ? _errors$name$message : null
        }))
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.TextField, _objectSpread(_objectSpread({
          required: true,
          error: !!errors.slug,
          variant: "outlined",
          fullWidth: true,
          placeholder: "E.g. cadet-college-admission",
          id: "slug",
          label: "Unique url slug"
        }, register("slug")), {}, {
          helperText: (_errors$slug$message = (_errors$slug = errors.slug) === null || _errors$slug === void 0 ? void 0 : _errors$slug.message) !== null && _errors$slug$message !== void 0 ? _errors$slug$message : null
        }))
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.FormControl, {
          sx: {
            minWidth: 271
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.InputLabel, {
            id: "category",
            children: "Select Category"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Select, {
            labelId: "category",
            id: "category",
            value: category || '',
            label: "Select Category",
            onChange: event => handleCategoryChange(event),
            error: !!(errors !== null && errors !== void 0 && errors.category),
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
              value: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("em", {
                children: "None"
              })
            }), categories === null || categories === void 0 ? void 0 : categories.map((cat, key) => /*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
              value: cat._id,
              children: cat.name
            }, key))]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.FormHelperText, {
            sx: {
              color: '#d32f2f'
            },
            children: (_errors$category$mess = errors === null || errors === void 0 ? void 0 : (_errors$category = errors.category) === null || _errors$category === void 0 ? void 0 : _errors$category.message) !== null && _errors$category$mess !== void 0 ? _errors$category$mess : null
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.FormControl, {
          sx: {
            minWidth: 271
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.InputLabel, {
            id: "subCategory",
            children: "Select Sub-Category"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Select, {
            labelId: "subCategory",
            id: "subCategory",
            value: subcategory || '',
            label: "Select Sub-Category",
            onChange: event => handleSubcategoryChange(event),
            error: !!(errors !== null && errors !== void 0 && errors.subCategory),
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
              value: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("em", {
                children: "None"
              })
            }), subCategories === null || subCategories === void 0 ? void 0 : subCategories.map((subCat, key) => /*#__PURE__*/jsx_runtime_.jsx(material_.MenuItem, {
              value: subCat,
              children: subCat
            }, key))]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.FormHelperText, {
            sx: {
              color: '#d32f2f'
            },
            children: (_errors$subCategory$m = errors === null || errors === void 0 ? void 0 : (_errors$subCategory = errors.subCategory) === null || _errors$subCategory === void 0 ? void 0 : _errors$subCategory.message) !== null && _errors$subCategory$m !== void 0 ? _errors$subCategory$m : null
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(FilePondUploader/* default */.Z, {
          required: true,
          id: "image",
          getUrl: getSecureUrl
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.TextField, _objectSpread(_objectSpread({
          required: true,
          error: !!errors.price,
          variant: "outlined",
          fullWidth: true,
          id: "price",
          label: "Course Fee"
        }, register("price")), {}, {
          helperText: (_errors$price$message = (_errors$price = errors.price) === null || _errors$price === void 0 ? void 0 : _errors$price.message) !== null && _errors$price$message !== void 0 ? _errors$price$message : null
        }))
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(CustomRadioButton, {
          label: "Language Medium",
          value: languageMediumValue,
          handleChange: handleLanguageChange,
          options: constants/* LANGUAGE_MEDIUM */.Ty
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(CustomCheckBox, {
          checked: isFeaturedValue,
          handleChange: handleIsFeatured,
          label: "Is Featured"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(CustomCheckBox, {
          checked: isOfferedValue,
          handleChange: handleIsOffered,
          label: "Is Offered"
        })
      }), isOfferedValue && /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.TextField, _objectSpread(_objectSpread({
          error: !!errors.offerInPercentage,
          variant: "outlined",
          fullWidth: true,
          id: "offerInPercentage",
          label: "Offer In Percentage"
        }, register("offerInPercentage")), {}, {
          helperText: (_errors$offerInPercen = (_errors$offerInPercen2 = errors.offerInPercentage) === null || _errors$offerInPercen2 === void 0 ? void 0 : _errors$offerInPercen2.message) !== null && _errors$offerInPercen !== void 0 ? _errors$offerInPercen : null
        }))
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        md: 6,
        children: /*#__PURE__*/jsx_runtime_.jsx(CustomCheckBox, {
          checked: docStatusValue,
          handleChange: handleDocStatusChange,
          label: "Publish"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/jsx_runtime_.jsx(common_CkEditor, {
          getEditorData: getEditorData,
          defaultData: itemData === null || itemData === void 0 ? void 0 : itemData.description
        })
      })]
    })
  }));
};

/* harmony default export */ const courses_CourseAddEditPopup = (CourseAddEditPopup);

/***/ })

};
;