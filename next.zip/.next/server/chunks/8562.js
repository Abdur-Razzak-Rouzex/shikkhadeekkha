"use strict";
exports.id = 8562;
exports.ids = [8562];
exports.modules = {

/***/ 8562:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3308);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_error__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9873);
/* harmony import */ var _components_common_modals_HookFormMuiModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(214);
/* harmony import */ var _components_common_button_SubmitButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7324);
/* harmony import */ var _components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6504);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_Store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2236);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
const _excluded = ["itemId", "refreshDataTable"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

















const initialValues = {
  questions: '',
  answer: ''
};

const FAQAddEditPopup = _ref => {
  var _errors$questions$mes, _errors$questions, _errors$answer$messag, _errors$answer;

  let {
    itemId,
    refreshDataTable
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    enqueueSnackbar
  } = (0,notistack__WEBPACK_IMPORTED_MODULE_4__.useSnackbar)();
  const isEdit = itemId != null;
  const {
    state
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_utils_Store__WEBPACK_IMPORTED_MODULE_10__/* .Store */ .y);
  const {
    userInfo
  } = state;
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
  const {
    0: itemData,
    1: setItemData
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(initialValues);
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (!(userInfo !== null && userInfo !== void 0 && userInfo.name)) {
      router.push('/login');
    }

    const getFAQ = async () => {
      try {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_9___default().get(`/api/faq/${itemId}`, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        setItemData(data);
      } catch (error) {
        enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
          variant: 'error'
        });
      }
    };

    if (itemId) {
      getFAQ();
    }
  }, [itemId]);
  const validationSchema = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    return yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
      questions: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Question"),
      answer: yup__WEBPACK_IMPORTED_MODULE_0__.string().required().label("Answer")
    });
  }, []);
  const {
    register,
    reset,
    handleSubmit,
    formState: {
      errors,
      isSubmitting
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(validationSchema)
  });
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    if (itemData) {
      reset({
        questions: itemData === null || itemData === void 0 ? void 0 : itemData.questions,
        answer: itemData === null || itemData === void 0 ? void 0 : itemData.answer
      });
    } else {
      reset(initialValues);
    }
  }, [itemData, reset]);

  const onSubmit = async data => {
    try {
      if (itemId) {
        await axios__WEBPACK_IMPORTED_MODULE_9___default().put(`/api/faq/${itemId}`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('FAQ updated successfully', {
          variant: 'success'
        });
      } else {
        await axios__WEBPACK_IMPORTED_MODULE_9___default().post(`/api/faq`, data, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        enqueueSnackbar('FAQ created successfully', {
          variant: 'success'
        });
      }

      props.onClose();
      refreshDataTable();
    } catch (error) {
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_13__/* .getError */ .b)(error), {
        variant: 'error'
      });
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_modals_HookFormMuiModal__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, _objectSpread(_objectSpread({
    open: true
  }, props), {}, {
    title: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: isEdit ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Edit FAQ"
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        component: 'span',
        variant: 'h5',
        children: "Add a new FAQ"
      })
    }),
    maxWidth: 'md',
    handleSubmit: handleSubmit(onSubmit),
    actions: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_button_CancelButton__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
        onClick: props.onClose
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_button_SubmitButton__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
        isSubmitting: isSubmitting
      })]
    }),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
      container: true,
      spacing: 5,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.questions,
          variant: "outlined",
          fullWidth: true,
          id: "questions",
          label: "Question"
        }, register("questions")), {}, {
          helperText: (_errors$questions$mes = (_errors$questions = errors.questions) === null || _errors$questions === void 0 ? void 0 : _errors$questions.message) !== null && _errors$questions$mes !== void 0 ? _errors$questions$mes : null
        }))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        item: true,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, _objectSpread(_objectSpread({
          error: !!errors.answer,
          variant: "outlined",
          fullWidth: true,
          id: "answer",
          label: "Answer",
          rows: 3,
          multiline: true
        }, register("answer")), {}, {
          helperText: (_errors$answer$messag = (_errors$answer = errors.answer) === null || _errors$answer === void 0 ? void 0 : _errors$answer.message) !== null && _errors$answer$messag !== void 0 ? _errors$answer$messag : null
        }))
      })]
    })
  }));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FAQAddEditPopup);

/***/ })

};
;