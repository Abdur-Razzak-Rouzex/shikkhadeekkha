"use strict";
(() => {
var exports = {};
exports.id = 435;
exports.ids = [435];
exports.modules = {

/***/ 8612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const NoDataFoundComponent = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid, {
    container: true,
    sx: {
      justifyContent: 'center',
      marginTop: 5
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography, {
      variant: "h1",
      component: "h1",
      children: "No data found"
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NoDataFoundComponent);

/***/ }),

/***/ 4900:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const faqSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  questions: {
    type: String,
    required: true
  },
  answer: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});
const FAQ = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.FAQ) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('FAQ', faqSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FAQ);

/***/ }),

/***/ 5753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_FAQs),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./components/Layout.js + 2 modules
var Layout = __webpack_require__(1783);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
;// CONCATENATED MODULE: external "@mui/icons-material/ExpandMore"
const ExpandMore_namespaceObject = require("@mui/icons-material/ExpandMore");
var ExpandMore_default = /*#__PURE__*/__webpack_require__.n(ExpandMore_namespaceObject);
// EXTERNAL MODULE: ./models/FAQ.js
var FAQ = __webpack_require__(4900);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(6420);
// EXTERNAL MODULE: ./components/common/NoDataFoundComponent.js
var NoDataFoundComponent = __webpack_require__(8612);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./pages/FAQs.js









const FAQs = props => {
  const {
    faqs
  } = props;
  return /*#__PURE__*/jsx_runtime_.jsx(Layout/* default */.Z, {
    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      component: "section",
      sx: {
        paddingBottom: 5
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Container, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          mb: 10,
          mt: 10,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h1",
            align: "center",
            component: "h1",
            children: "Frequent Asked Questions"
          })
        }), (faqs === null || faqs === void 0 ? void 0 : faqs.length) > 0 ? /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          container: true,
          spacing: 3,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
            item: true,
            xs: 12,
            children: faqs === null || faqs === void 0 ? void 0 : faqs.map(faq => /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Accordion, {
              sx: {
                marginBottom: '10px'
              },
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.AccordionSummary, {
                expandIcon: /*#__PURE__*/jsx_runtime_.jsx((ExpandMore_default()), {}),
                "aria-controls": "panel1a-content",
                id: "panel1a-header",
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  children: faq === null || faq === void 0 ? void 0 : faq.questions
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Divider, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.AccordionDetails, {
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  children: faq === null || faq === void 0 ? void 0 : faq.answer
                })
              })]
            }, faq._id))
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx(NoDataFoundComponent/* default */.Z, {})]
      })
    })
  });
};

async function getServerSideProps() {
  await db/* default.connect */.Z.connect();
  const faqDoc = await FAQ/* default.find */.Z.find({}).lean();
  return {
    props: {
      faqs: faqDoc.map(db/* default.convertDocToObj */.Z.convertDocToObj)
    }
  };
}
/* harmony default export */ const pages_FAQs = (FAQs);

/***/ }),

/***/ 874:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 2737:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Dashboard");

/***/ }),

/***/ 1041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HelpCenter");

/***/ }),

/***/ 1090:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 9613:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 586:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Login");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 4734:
/***/ ((module) => {

module.exports = require("@mui/icons-material/School");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 3801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 7949:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8035:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3061,2236,6420,3391,3296], () => (__webpack_exec__(5753)));
module.exports = __webpack_exports__;

})();