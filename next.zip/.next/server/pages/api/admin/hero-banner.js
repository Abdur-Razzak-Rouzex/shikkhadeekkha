"use strict";
(() => {
var exports = {};
exports.id = 7894;
exports.ids = [7894];
exports.modules = {

/***/ 1105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const heroBannerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  imgUrl: {
    type: String,
    required: true
  },
  link: {
    type: String,
    required: false
  },
  altTitle: {
    type: String,
    required: false,
    default: 'Cadet Coaching'
  }
}, {
  timestamps: true
});
const HeroBanner = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.HeroBanner) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('HeroBanner', heroBannerSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroBanner);

/***/ }),

/***/ 9968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9303);
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_connect__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2898);
/* harmony import */ var _models_HeroBanner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1105);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6420);




const handler = next_connect__WEBPACK_IMPORTED_MODULE_0___default()();
handler.get(async (req, res) => {
  await _utils_db__WEBPACK_IMPORTED_MODULE_3__/* .default.connect */ .Z.connect();
  const heroBanners = await _models_HeroBanner__WEBPACK_IMPORTED_MODULE_2__/* .default.find */ .Z.find({});
  res.send(heroBanners);
});
handler.use(_utils_auth__WEBPACK_IMPORTED_MODULE_1__/* .isAuth */ .$D, _utils_auth__WEBPACK_IMPORTED_MODULE_1__/* .isAdmin */ .GJ);
handler.post(async (req, res) => {
  await _utils_db__WEBPACK_IMPORTED_MODULE_3__/* .default.connect */ .Z.connect();
  const newHeroBanner = new _models_HeroBanner__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z({
    imgUrl: req.body.imgUrl,
    link: req.body.link,
    altTitle: req.body.altTitle
  });
  const heroBanner = await newHeroBanner.save();
  res.send({
    message: 'Hero Banner Created',
    heroBanner
  });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

/***/ }),

/***/ 9722:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6420,2898], () => (__webpack_exec__(9968)));
module.exports = __webpack_exports__;

})();