"use strict";
(() => {
var exports = {};
exports.id = 5248;
exports.ids = [5248];
exports.modules = {

/***/ 5189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9303);
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_connect__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2898);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6420);
/* harmony import */ var _utils_error__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9873);
/* harmony import */ var _models_AdmissionForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3507);





const handler = next_connect__WEBPACK_IMPORTED_MODULE_0___default()({
  onError: _utils_error__WEBPACK_IMPORTED_MODULE_4__/* .onError */ .q
});
handler.use(_utils_auth__WEBPACK_IMPORTED_MODULE_1__/* .isAuth */ .$D);
handler.post(async (req, res) => {
  var _req$body, _req$body2, _req$body3, _req$body4;

  await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* .default.connect */ .Z.connect();
  const studentInfo = req === null || req === void 0 ? void 0 : (_req$body = req.body) === null || _req$body === void 0 ? void 0 : _req$body.studentInfo;
  const parentsInfo = req === null || req === void 0 ? void 0 : (_req$body2 = req.body) === null || _req$body2 === void 0 ? void 0 : _req$body2.parentsInfo;
  const academicGuardianInfo = req === null || req === void 0 ? void 0 : (_req$body3 = req.body) === null || _req$body3 === void 0 ? void 0 : _req$body3.academicGuardianInfo;
  const otherInfo = req === null || req === void 0 ? void 0 : (_req$body4 = req.body) === null || _req$body4 === void 0 ? void 0 : _req$body4.otherInfo;
  const newAdmission = new _models_AdmissionForm__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z({
    studentInfo: studentInfo,
    parentsInfo: parentsInfo,
    academicGuardianInfo: academicGuardianInfo,
    otherInfo: otherInfo,
    user: req.user._id
  });
  const admission = await newAdmission.save();
  res.status(201).send(admission);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

/***/ }),

/***/ 9873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getError),
/* harmony export */   "q": () => (/* binding */ onError)
/* harmony export */ });
const getError = err => {
  var _err$response$data$me, _err$response, _err$response$data;

  return (_err$response$data$me = err === null || err === void 0 ? void 0 : (_err$response = err.response) === null || _err$response === void 0 ? void 0 : (_err$response$data = _err$response.data) === null || _err$response$data === void 0 ? void 0 : _err$response$data.message) !== null && _err$response$data$me !== void 0 ? _err$response$data$me : err.message;
};

const onError = async (err, req, res, next) => {
  res.status(500).send({
    message: err.toString()
  });
};



/***/ }),

/***/ 9722:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6420,2898,3507], () => (__webpack_exec__(5189)));
module.exports = __webpack_exports__;

})();