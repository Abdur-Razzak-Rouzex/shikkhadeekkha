"use strict";
(() => {
var exports = {};
exports.id = 8873;
exports.ids = [8873];
exports.modules = {

/***/ 5639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const userSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String
  },
  password: {
    type: String,
    required: true
  },
  isAdmin: {
    type: Boolean,
    required: true,
    default: false
  }
}, {
  timestamps: true
});
const User = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.User) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('User', userSchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);

/***/ }),

/***/ 7790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ reviews)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(5619);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
// EXTERNAL MODULE: external "next-connect"
var external_next_connect_ = __webpack_require__(9303);
var external_next_connect_default = /*#__PURE__*/__webpack_require__.n(external_next_connect_);
// EXTERNAL MODULE: ./utils/error.js
var error = __webpack_require__(9873);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(6420);
// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__(2898);
;// CONCATENATED MODULE: ./models/Review.js

const reviewSchema = new (external_mongoose_default()).Schema({
  product: {
    type: (external_mongoose_default()).Schema.Types.ObjectId,
    ref: 'Course',
    required: true
  },
  user: {
    type: (external_mongoose_default()).Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  rating: {
    type: Number,
    default: 0
  },
  comment: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});
const Review = (external_mongoose_default()).models.Review || external_mongoose_default().model('Review', reviewSchema);
/* harmony default export */ const models_Review = (Review);
// EXTERNAL MODULE: ./models/Course.js
var Course = __webpack_require__(3291);
// EXTERNAL MODULE: ./models/User.js
var User = __webpack_require__(5639);
;// CONCATENATED MODULE: ./pages/api/products/[id]/reviews.js
// /api/products/:id/reviews








const handler = external_next_connect_default()({
  onError: error/* onError */.q
});
handler.get(async (req, res) => {
  await db/* default.connect */.Z.connect();
  const review = await models_Review.find({
    product: req.query.id
  }).populate('user', 'name', User/* default */.Z);

  if (review) {
    res.send(review);
  } else {
    res.status(404).send({
      message: 'Course not found'
    });
  }
});
handler.use(auth/* isAuth */.$D).post(async (req, res) => {
  await db/* default.connect */.Z.connect();
  const course = await Course/* default.findById */.Z.findById(req.query.id);

  if (course) {
    var _req$query, _req$query2;

    const newReview = new models_Review({
      product: external_mongoose_default().Types.ObjectId(req === null || req === void 0 ? void 0 : (_req$query = req.query) === null || _req$query === void 0 ? void 0 : _req$query.id),
      user: external_mongoose_default().Types.ObjectId(req.user._id),
      rating: Number(req.body.rating),
      comment: req.body.comment
    });
    await newReview.save();
    const reviews = await models_Review.find({
      product: req === null || req === void 0 ? void 0 : (_req$query2 = req.query) === null || _req$query2 === void 0 ? void 0 : _req$query2.id
    });
    course.numOfReviews = reviews.length;
    course.rating = reviews.reduce((a, c) => c.rating + a, 0) / reviews.length;
    await course.save();
    res.status(201).send({
      message: 'Review submitted'
    });
  } else {
    res.status(404).send({
      message: 'Product Not Found'
    });
  }
});
/* harmony default export */ const reviews = (handler);

/***/ }),

/***/ 9873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getError),
/* harmony export */   "q": () => (/* binding */ onError)
/* harmony export */ });
const getError = err => {
  var _err$response$data$me, _err$response, _err$response$data;

  return (_err$response$data$me = err === null || err === void 0 ? void 0 : (_err$response = err.response) === null || _err$response === void 0 ? void 0 : (_err$response$data = _err$response.data) === null || _err$response$data === void 0 ? void 0 : _err$response$data.message) !== null && _err$response$data$me !== void 0 ? _err$response$data$me : err.message;
};

const onError = async (err, req, res, next) => {
  res.status(500).send({
    message: err.toString()
  });
};



/***/ }),

/***/ 9722:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9303:
/***/ ((module) => {

module.exports = require("next-connect");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6420,2898,3291], () => (__webpack_exec__(7790)));
module.exports = __webpack_exports__;

})();