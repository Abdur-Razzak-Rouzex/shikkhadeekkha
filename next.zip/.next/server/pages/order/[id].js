"use strict";
(() => {
var exports = {};
exports.id = 8441;
exports.ids = [8441];
exports.modules = {

/***/ 5943:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1783);
/* harmony import */ var _utils_Store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2236);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2470);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7949);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_classes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3391);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3308);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils_error__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9873);
/* harmony import */ var _components_common_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7733);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














/*import {PayPalButtons, usePayPalScriptReducer} from '@paypal/react-paypal-js';*/





function reducer(state, action) {
  switch (action.type) {
    case 'FETCH_REQUEST':
      return _objectSpread(_objectSpread({}, state), {}, {
        loading: true,
        error: ''
      });

    case 'FETCH_SUCCESS':
      return _objectSpread(_objectSpread({}, state), {}, {
        loading: false,
        order: action.payload,
        error: ''
      });

    case 'FETCH_FAIL':
      return _objectSpread(_objectSpread({}, state), {}, {
        loading: false,
        error: action.payload
      });

    case 'PAY_REQUEST':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingPay: true
      });

    case 'PAY_SUCCESS':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingPay: false,
        successPay: true
      });

    case 'PAY_FAIL':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingPay: false,
        errorPay: action.payload
      });

    case 'PAY_RESET':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingPay: false,
        successPay: false,
        errorPay: ''
      });

    case 'DELIVER_REQUEST':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingDeliver: true
      });

    case 'DELIVER_SUCCESS':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingDeliver: false,
        successDeliver: true
      });

    case 'DELIVER_FAIL':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingDeliver: false,
        errorDeliver: action.payload
      });

    case 'DELIVER_RESET':
      return _objectSpread(_objectSpread({}, state), {}, {
        loadingDeliver: false,
        successDeliver: false,
        errorDeliver: ''
      });

    default:
      return state;
  }
}

function Order({
  params
}) {
  var _orderItems$, _shippingAddress$loca, _shippingAddress$loca2;

  const orderId = params.id;
  /*const [{isPending}, paypalDispatch] = usePayPalScriptReducer();*/

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
  const {
    state
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_utils_Store__WEBPACK_IMPORTED_MODULE_3__/* .Store */ .y);
  const {
    userInfo
  } = state;
  const {
    0: {
      loading,
      error,
      order,
      successPay,
      loadingDeliver,
      successDeliver
    },
    1: dispatch
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useReducer)(reducer, {
    loading: true,
    order: {},
    error: ''
  });
  const {
    shippingAddress,
    paymentMethod,
    orderItems,
    itemsPrice,
    shippingPrice,
    totalPrice,
    isPaid,
    paidAt,
    isDelivered,
    deliveredAt
  } = order;
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!(userInfo !== null && userInfo !== void 0 && userInfo.name)) {
      return router.push('/login');
    }

    const fetchOrder = async () => {
      try {
        dispatch({
          type: 'FETCH_REQUEST'
        });
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_8___default().get(`/api/orders/${orderId}`, {
          headers: {
            authorization: `Bearer ${userInfo.token}`
          }
        });
        dispatch({
          type: 'FETCH_SUCCESS',
          payload: data
        });
      } catch (err) {
        dispatch({
          type: 'FETCH_FAIL',
          payload: (0,_utils_error__WEBPACK_IMPORTED_MODULE_14__/* .getError */ .b)(err)
        });
      }
    };

    if (!order._id || successPay || successDeliver || order._id && order._id !== orderId) {
      fetchOrder();

      if (successPay) {
        dispatch({
          type: 'PAY_RESET'
        });
      }

      if (successDeliver) {
        dispatch({
          type: 'DELIVER_RESET'
        });
      }
    }
  }, [order, successPay, successDeliver]);
  const {
    enqueueSnackbar
  } = (0,notistack__WEBPACK_IMPORTED_MODULE_11__.useSnackbar)();
  /*    function createOrder(data, actions) {
          return actions.order
              .create({
                  purchase_units: [
                      {
                          amount: {value: totalPrice},
                      },
                  ],
              })
              .then((orderID) => {
                  return orderID;
              });
      }*/

  /*    function onApprove(data, actions) {
          return actions.order.capture().then(async function (details) {
              try {
                  dispatch({type: 'PAY_REQUEST'});
                  const {data} = await axios.put(
                      `/api/orders/${order._id}/pay`,
                      details,
                      {
                          headers: {authorization: `Bearer ${userInfo.token}`},
                      }
                  );
                  dispatch({type: 'PAY_SUCCESS', payload: data});
                  enqueueSnackbar('Order is paid', {variant: 'success'});
              } catch (err) {
                  dispatch({type: 'PAY_FAIL', payload: getError(err)});
                  enqueueSnackbar(getError(err), {variant: 'error'});
              }
          });
      }*/

  /*
      function onError(err) {
          enqueueSnackbar(getError(err), {variant: 'error'});
      }
  */

  /** payment handler */

  async function makePaymentHandler() {
    try {
      dispatch({
        type: 'PAY_REQUEST'
      });
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_8___default().put(`/api/orders/${order._id}/pay`, {}, {
        headers: {
          authorization: `Bearer ${userInfo.token}`
        }
      });
      dispatch({
        type: 'PAY_SUCCESS',
        payload: data
      });
      enqueueSnackbar('Order is paid', {
        variant: 'success'
      });
    } catch (err) {
      dispatch({
        type: 'PAY_FAIL',
        payload: (0,_utils_error__WEBPACK_IMPORTED_MODULE_14__/* .getError */ .b)(err)
      });
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_14__/* .getError */ .b)(err), {
        variant: 'error'
      });
    }
  }
  /** delivery handler */


  async function deliverOrderHandler() {
    try {
      dispatch({
        type: 'DELIVER_REQUEST'
      });
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_8___default().put(`/api/orders/${order._id}/deliver`, {}, {
        headers: {
          authorization: `Bearer ${userInfo.token}`
        }
      });
      dispatch({
        type: 'DELIVER_SUCCESS',
        payload: data
      });
      enqueueSnackbar('Order is delivered', {
        variant: 'success'
      });
    } catch (err) {
      dispatch({
        type: 'DELIVER_FAIL',
        payload: (0,_utils_error__WEBPACK_IMPORTED_MODULE_14__/* .getError */ .b)(err)
      });
      enqueueSnackbar((0,_utils_error__WEBPACK_IMPORTED_MODULE_14__/* .getError */ .b)(err), {
        variant: 'error'
      });
    }
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_components_Layout__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
    title: `Order ${orderId}`,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
      component: "h1",
      variant: "h1",
      children: ["Order ", orderId]
    }), loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.CircularProgress, {}) : error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
      sx: _utils_classes__WEBPACK_IMPORTED_MODULE_10__/* .default.error */ .Z.error,
      children: error
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
      container: true,
      spacing: 1,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
        item: true,
        md: 9,
        xs: 12,
        children: [((_orderItems$ = orderItems[0]) === null || _orderItems$ === void 0 ? void 0 : _orderItems$.type) !== _components_common_constants__WEBPACK_IMPORTED_MODULE_12__/* .COURSE_TYPE */ .R3 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Card, {
          sx: _utils_classes__WEBPACK_IMPORTED_MODULE_10__/* .default.section */ .Z.section,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.List, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                component: "h2",
                variant: "h2",
                children: "Shipping Address"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: [shippingAddress === null || shippingAddress === void 0 ? void 0 : shippingAddress.fullName, ", ", shippingAddress === null || shippingAddress === void 0 ? void 0 : shippingAddress.address, ",", ' ', shippingAddress === null || shippingAddress === void 0 ? void 0 : shippingAddress.city, ", ", shippingAddress === null || shippingAddress === void 0 ? void 0 : shippingAddress.postalCode, ",", ' ', shippingAddress === null || shippingAddress === void 0 ? void 0 : shippingAddress.country, "\xA0", (shippingAddress === null || shippingAddress === void 0 ? void 0 : shippingAddress.location) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Link, {
                variant: "button",
                target: "_new",
                href: `https://maps.google.com?q=${shippingAddress === null || shippingAddress === void 0 ? void 0 : (_shippingAddress$loca = shippingAddress.location) === null || _shippingAddress$loca === void 0 ? void 0 : _shippingAddress$loca.lat},${shippingAddress === null || shippingAddress === void 0 ? void 0 : (_shippingAddress$loca2 = shippingAddress.location) === null || _shippingAddress$loca2 === void 0 ? void 0 : _shippingAddress$loca2.lng}`,
                children: "Show On Map"
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: ["Delivery Status:", ' ', isDelivered ? `Delivered at ${deliveredAt}` : 'Not Delivered']
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Card, {
          sx: _utils_classes__WEBPACK_IMPORTED_MODULE_10__/* .default.section */ .Z.section,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.List, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                component: "h2",
                variant: "h2",
                children: "Payment"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                container: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    children: "Payment Method:"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Chip, {
                    label: paymentMethod,
                    size: "medium",
                    color: "primary"
                  })
                })]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                container: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    children: "Payment Status:"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: isPaid ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Chip, {
                    label: `Paid at ${moment__WEBPACK_IMPORTED_MODULE_6___default()(paidAt).format('MMMM Do YYYY, h:mm:ss a')}`,
                    size: "medium",
                    color: "secondary"
                  }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Chip, {
                    label: "Not Paid",
                    size: "medium",
                    color: "primary"
                  })
                })]
              })
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Card, {
          sx: _utils_classes__WEBPACK_IMPORTED_MODULE_10__/* .default.section */ .Z.section,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.List, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                component: "h2",
                variant: "h2",
                children: "Order Items"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableContainer, {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Table, {
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableHead, {
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableRow, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        children: "Image"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        children: "Name"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        align: "right",
                        children: "Quantity"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        align: "right",
                        children: "Price"
                      })]
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableBody, {
                    children: orderItems.map(item => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableRow, {
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__.default, {
                          href: `/product/${item.slug}`,
                          passHref: true,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Link, {
                            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(next_image__WEBPACK_IMPORTED_MODULE_5__.default, {
                              src: item.image,
                              alt: item.name,
                              width: 50,
                              height: 50
                            })
                          })
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__.default, {
                          href: `/product/${item.slug}`,
                          passHref: true,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Link, {
                            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                              children: item.name
                            })
                          })
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        align: "right",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                          children: item.quantity
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.TableCell, {
                        align: "right",
                        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                          children: [item.price, " \u09F3"]
                        })
                      })]
                    }, item._id))
                  })]
                })
              })
            })]
          })
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
        item: true,
        md: 3,
        xs: 12,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Card, {
          sx: _utils_classes__WEBPACK_IMPORTED_MODULE_10__/* .default.section */ .Z.section,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.List, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                variant: "h2",
                children: "Order Summary"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                container: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    children: "Items:"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    align: "right",
                    children: [itemsPrice, " \u09F3"]
                  })
                })]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                container: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    children: "Shipping:"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    align: "right",
                    children: [shippingPrice, " \u09F3"]
                  })
                })]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                container: true,
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx("strong", {
                      children: "Total:"
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Grid, {
                  item: true,
                  xs: 6,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Typography, {
                    align: "right",
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)("strong", {
                      children: [totalPrice, " \u09F3"]
                    })
                  })
                })]
              })
            }), (userInfo === null || userInfo === void 0 ? void 0 : userInfo.isAdmin) && !isPaid && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: [loadingDeliver && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.CircularProgress, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Button, {
                fullWidth: true,
                variant: "contained",
                color: "primary",
                onClick: makePaymentHandler,
                children: "Make Payment"
              })]
            }), (userInfo === null || userInfo === void 0 ? void 0 : userInfo.isAdmin) && (order === null || order === void 0 ? void 0 : order.isPaid) && !(order !== null && order !== void 0 && order.isDelivered) && orderItems[0].type !== _components_common_constants__WEBPACK_IMPORTED_MODULE_12__/* .COURSE_TYPE */ .R3 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.ListItem, {
              children: [loadingDeliver && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.CircularProgress, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Button, {
                fullWidth: true,
                variant: "contained",
                color: "primary",
                onClick: deliverOrderHandler,
                children: "Deliver Order"
              })]
            })]
          })
        })
      })]
    })]
  });
}

async function getServerSideProps({
  params
}) {
  return {
    props: {
      params
    }
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__.default)(() => Promise.resolve(Order), {
  ssr: false
}));

/***/ }),

/***/ 9873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getError),
/* harmony export */   "q": () => (/* binding */ onError)
/* harmony export */ });
const getError = err => {
  var _err$response$data$me, _err$response, _err$response$data;

  return (_err$response$data$me = err === null || err === void 0 ? void 0 : (_err$response = err.response) === null || _err$response === void 0 ? void 0 : (_err$response$data = _err$response.data) === null || _err$response$data === void 0 ? void 0 : _err$response$data.message) !== null && _err$response$data$me !== void 0 ? _err$response$data$me : err.message;
};

const onError = async (err, req, res, next) => {
  res.status(500).send({
    message: err.toString()
  });
};



/***/ }),

/***/ 874:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 2737:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Dashboard");

/***/ }),

/***/ 1041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HelpCenter");

/***/ }),

/***/ 1090:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 9613:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 586:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Login");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 4734:
/***/ ((module) => {

module.exports = require("@mui/icons-material/School");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 3801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 7949:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8035:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3308:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3061,5152,2236,3391,3296,7733], () => (__webpack_exec__(5943)));
module.exports = __webpack_exports__;

})();