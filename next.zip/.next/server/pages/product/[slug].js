"use strict";
(() => {
var exports = {};
exports.id = 2915;
exports.ids = [2915];
exports.modules = {

/***/ 736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8035);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);

const Form = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)('form')(() => ({
  width: '100%',
  maxWidth: 800,
  margin: '0 auto'
}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);

/***/ }),

/***/ 6290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5619);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const categorySchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: true
  },
  subCategory: [{
    type: String
  }]
}, {
  timestamps: true
});
const Category = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Category) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Category', categorySchema);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);

/***/ }),

/***/ 4605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProductScreen),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(7949);
// EXTERNAL MODULE: external "@mui/material/Rating"
var Rating_ = __webpack_require__(4459);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating_);
// EXTERNAL MODULE: ./components/Layout.js + 2 modules
var Layout = __webpack_require__(1783);
// EXTERNAL MODULE: ./utils/classes.js
var classes = __webpack_require__(3391);
// EXTERNAL MODULE: ./utils/db.js
var db = __webpack_require__(6420);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./utils/Store.js
var Store = __webpack_require__(2236);
// EXTERNAL MODULE: ./utils/error.js
var error = __webpack_require__(9873);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "notistack"
var external_notistack_ = __webpack_require__(3308);
// EXTERNAL MODULE: ./components/Form.js
var Form = __webpack_require__(736);
// EXTERNAL MODULE: ./models/Course.js
var Course = __webpack_require__(3291);
;// CONCATENATED MODULE: external "@mui/material/Tabs"
const Tabs_namespaceObject = require("@mui/material/Tabs");
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Tab"
const Tab_namespaceObject = require("@mui/material/Tab");
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab_namespaceObject);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/TabPanel.js
const _excluded = ["children", "value", "index"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



function TabPanel(props) {
  const {
    children,
    value,
    index
  } = props,
        other = _objectWithoutProperties(props, _excluded);

  return /*#__PURE__*/jsx_runtime_.jsx("div", _objectSpread(_objectSpread({
    role: "tabpanel",
    hidden: value !== index,
    id: `simple-tabpanel-${index}`,
    "aria-labelledby": `simple-tab-${index}`
  }, other), {}, {
    children: value === index && /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      sx: {
        p: 3
      },
      children: children
    })
  }));
}
function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
  };
}
// EXTERNAL MODULE: ./models/Category.js
var Category = __webpack_require__(6290);
// EXTERNAL MODULE: ./components/common/constants.js
var constants = __webpack_require__(7733);
// EXTERNAL MODULE: ./utils/helpers.js
var helpers = __webpack_require__(8054);
;// CONCATENATED MODULE: ./pages/product/[slug].js
function _slug_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _slug_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { _slug_ownKeys(Object(source), true).forEach(function (key) { _slug_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { _slug_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _slug_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
























function ProductScreen(props) {
  var _course$category;

  const router = (0,router_.useRouter)();
  const {
    state,
    dispatch
  } = (0,external_react_.useContext)(Store/* Store */.y);
  const {
    userInfo
  } = state;
  const {
    course
  } = props;
  const {
    enqueueSnackbar
  } = (0,external_notistack_.useSnackbar)();
  const {
    0: reviews,
    1: setReviews
  } = (0,external_react_.useState)([]);
  const {
    0: rating,
    1: setRating
  } = (0,external_react_.useState)(0);
  const {
    0: comment,
    1: setComment
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const [value, setValue] = external_react_default().useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const fetchReviews = async () => {
    try {
      const {
        data
      } = await external_axios_default().get(`/api/products/${course === null || course === void 0 ? void 0 : course._id}/reviews`);
      setReviews(data);
    } catch (err) {
      enqueueSnackbar((0,error/* getError */.b)(err), {
        variant: 'error'
      });
    }
  };

  (0,external_react_.useEffect)(() => {
    if (course) {
      fetchReviews();
    }
  }, [course]);

  const reviewSubmitHandler = async e => {
    e.preventDefault();
    setLoading(true);

    try {
      await external_axios_default().post(`/api/products/${course === null || course === void 0 ? void 0 : course._id}/reviews`, {
        rating,
        comment
      }, {
        headers: {
          authorization: `Bearer ${userInfo.token}`
        }
      });
      setLoading(false);
      setRating(0);
      setComment('');
      enqueueSnackbar('Review submitted successfully', {
        variant: 'success'
      });
      fetchReviews();
    } catch (err) {
      setLoading(false);
      enqueueSnackbar((0,error/* getError */.b)(err), {
        variant: 'error'
      });
    }
  };

  const addToCartHandler = async () => {
    const existItem = state.cart.cartItems.find(x => (x === null || x === void 0 ? void 0 : x._id) === (course === null || course === void 0 ? void 0 : course._id));
    const quantity = existItem ? existItem.quantity + 1 : 1;
    const {
      data
    } = await external_axios_default().get(`/api/products/${course === null || course === void 0 ? void 0 : course._id}`);

    if (data.countInStock < quantity) {
      enqueueSnackbar('Sorry. Product is out of stock', {
        variant: 'error'
      });
      return;
    }

    dispatch({
      type: 'CART_ADD_ITEM',
      payload: _slug_objectSpread(_slug_objectSpread({}, course), {}, {
        quantity
      })
    });
    await router.push('/cart');
  };

  const enrollmentHandler = async () => {
    const existedItemType = state.cart.cartItems.find(item => (item === null || item === void 0 ? void 0 : item.type) === constants/* COURSE_TYPE */.R3);

    if (existedItemType) {
      enqueueSnackbar('Please complete the enrollment of the added course first', {
        variant: 'error'
      });
      await router.push('/cart');
    } else {
      const existItem = state.cart.cartItems.find(x => (x === null || x === void 0 ? void 0 : x._id) === (course === null || course === void 0 ? void 0 : course._id));
      const quantity = existItem ? existItem.quantity : 1;
      let offeredPrice;

      if (course !== null && course !== void 0 && course.isOffered) {
        offeredPrice = (0,helpers/* calculateOfferPrice */.$)(course === null || course === void 0 ? void 0 : course.price, course === null || course === void 0 ? void 0 : course.offerInPercentage);
      } else {
        offeredPrice = course === null || course === void 0 ? void 0 : course.price;
      }

      dispatch({
        type: 'CART_ADD_ITEM',
        payload: _slug_objectSpread(_slug_objectSpread({}, course), {}, {
          quantity,
          offeredPrice
        })
      });
      await router.push('/payment');
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
    title: (course === null || course === void 0 ? void 0 : course.name) || 'No Product Found',
    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
      sx: classes/* default.section */.Z.section,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/search",
        passHref: true,
        children: (course === null || course === void 0 ? void 0 : course.type) === constants/* COURSE_TYPE */.R3 ? /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            children: "View all courses"
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            children: "View all products"
          })
        })
      })
    }), course ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 1,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 5,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: course === null || course === void 0 ? void 0 : course.image,
            alt: course === null || course === void 0 ? void 0 : course.name,
            width: 400,
            height: 280,
            layout: "responsive"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 3,
          xs: 12,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.List, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                component: "h1",
                variant: "h1",
                children: course === null || course === void 0 ? void 0 : course.name
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
                children: ["Category: ", course === null || course === void 0 ? void 0 : (_course$category = course.category) === null || _course$category === void 0 ? void 0 : _course$category.name]
              })
            }), (course === null || course === void 0 ? void 0 : course.type) !== constants/* COURSE_TYPE */.R3 && /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
                children: ["Brand: ", course === null || course === void 0 ? void 0 : course.brand]
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
              children: [/*#__PURE__*/jsx_runtime_.jsx((Rating_default()), {
                value: course === null || course === void 0 ? void 0 : course.rating,
                readOnly: true
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                href: "#reviews",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
                  children: ["(", course === null || course === void 0 ? void 0 : course.numOfReviews, " reviews)"]
                })
              })]
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Card, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.List, {
              children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                  container: true,
                  children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 6,
                    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: "Price"
                    })
                  }), course !== null && course !== void 0 && course.isOffered ? /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 6,
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                      container: true,
                      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 6,
                        children: /*#__PURE__*/jsx_runtime_.jsx("del", {
                          style: {
                            color: 'red'
                          },
                          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Chip, {
                            label: `${course === null || course === void 0 ? void 0 : course.price} ৳`,
                            size: "small",
                            color: "primary"
                          })
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 6,
                        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Chip, {
                          label: `${(0,helpers/* calculateOfferPrice */.$)(course === null || course === void 0 ? void 0 : course.price, course === null || course === void 0 ? void 0 : course.offerInPercentage)} ৳`,
                          size: "medium",
                          color: "secondary",
                          sx: {
                            marginLeft: 2
                          }
                        })
                      })]
                    })
                  }) : /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 6,
                    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Chip, {
                      label: `${course === null || course === void 0 ? void 0 : course.price} ৳`,
                      size: "medium",
                      color: "secondary"
                    })
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                  container: true,
                  children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 6,
                    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: "Status"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
                    item: true,
                    xs: 6,
                    children: (course === null || course === void 0 ? void 0 : course.type) === constants/* COURSE_TYPE */.R3 ? /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: "Open for Enrollment"
                    }) : /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: (course === null || course === void 0 ? void 0 : course.countInStock) > 0 ? 'In stock' : 'Unavailable'
                    })
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                children: (course === null || course === void 0 ? void 0 : course.type) === constants/* COURSE_TYPE */.R3 ? /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                  fullWidth: true,
                  variant: "contained",
                  onClick: enrollmentHandler,
                  children: "Enroll Now"
                }) : /*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                  fullWidth: true,
                  variant: "contained",
                  onClick: addToCartHandler,
                  children: "Add to cart"
                })
              })]
            })
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
          width: '100%',
          marginTop: 5
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
          sx: {
            borderBottom: 1,
            borderColor: 'divider'
          },
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((Tabs_default()), {
            value: value,
            onChange: handleChange,
            "aria-label": "basic tabs example",
            children: [/*#__PURE__*/jsx_runtime_.jsx((Tab_default()), _slug_objectSpread({
              label: "Rating & Reviews"
            }, a11yProps(0))), /*#__PURE__*/jsx_runtime_.jsx((Tab_default()), _slug_objectSpread({
              label: "Description"
            }, a11yProps(1)))]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(TabPanel, {
          value: value,
          index: 0,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.List, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                name: "reviews",
                id: "reviews",
                variant: "h2",
                children: "Customer Reviews"
              })
            }), reviews.length === 0 && /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
              children: "No review"
            }), reviews.map(review => {
              var _review$user;

              return /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                  container: true,
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                    item: true,
                    sx: classes/* default.reviewItem */.Z.reviewItem,
                    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: /*#__PURE__*/jsx_runtime_.jsx("strong", {
                        children: review === null || review === void 0 ? void 0 : (_review$user = review.user) === null || _review$user === void 0 ? void 0 : _review$user.name
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: review === null || review === void 0 ? void 0 : review.createdAt.substring(0, 10)
                    })]
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                    item: true,
                    children: [/*#__PURE__*/jsx_runtime_.jsx((Rating_default()), {
                      value: review === null || review === void 0 ? void 0 : review.rating,
                      readOnly: true
                    }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      children: review === null || review === void 0 ? void 0 : review.comment
                    })]
                  })]
                })
              }, review._id);
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
              children: userInfo ? /*#__PURE__*/jsx_runtime_.jsx(Form/* default */.Z, {
                onSubmit: reviewSubmitHandler,
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.List, {
                  children: [/*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                    children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                      variant: "h2",
                      children: "Leave your review"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                    children: /*#__PURE__*/jsx_runtime_.jsx(material_.TextField, {
                      multiline: true,
                      variant: "outlined",
                      fullWidth: true,
                      name: "review",
                      label: "Enter comment",
                      value: comment,
                      onChange: e => setComment(e.target.value)
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(material_.ListItem, {
                    children: /*#__PURE__*/jsx_runtime_.jsx((Rating_default()), {
                      name: "simple-controlled",
                      value: rating,
                      onChange: e => setRating(e.target.value)
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.ListItem, {
                    children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Button, {
                      type: "submit",
                      fullWidth: true,
                      variant: "contained",
                      color: "primary",
                      children: "Submit"
                    }), loading && /*#__PURE__*/jsx_runtime_.jsx(material_.CircularProgress, {})]
                  })]
                })
              }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
                variant: "h2",
                children: ["Please", ' ', /*#__PURE__*/jsx_runtime_.jsx(material_.Link, {
                  href: `/login?redirect=/product/${course.slug}`,
                  children: "login"
                }), ' ', "to write a review"]
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(TabPanel, {
          value: value,
          index: 1,
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            dangerouslySetInnerHTML: {
              __html: course === null || course === void 0 ? void 0 : course.description
            }
          })
        })]
      })]
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Container, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        mt: 3,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h1",
          align: "center",
          component: "h1",
          color: "secondary",
          children: "Sorry !!! Your desired product is not found"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          textAlign: 'center'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/images/not-found.jpg",
          alt: "not-found",
          title: "not-found",
          width: 400,
          height: 400
        })
      })]
    })]
  });
}
async function getServerSideProps(context) {
  const {
    params
  } = context;
  const {
    slug
  } = params;
  await db/* default.connect */.Z.connect();
  const course = await Course/* default.findOne */.Z.findOne({
    slug: slug
  }).lean().populate('category', 'name', Category/* default */.Z);

  if (course === null) {
    return {
      props: {
        course: null
      }
    };
  }

  return {
    props: {
      course: db/* default.convertDocToObj */.Z.convertDocToObj(course)
    }
  };
}

/***/ }),

/***/ 9873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getError),
/* harmony export */   "q": () => (/* binding */ onError)
/* harmony export */ });
const getError = err => {
  var _err$response$data$me, _err$response, _err$response$data;

  return (_err$response$data$me = err === null || err === void 0 ? void 0 : (_err$response = err.response) === null || _err$response === void 0 ? void 0 : (_err$response$data = _err$response.data) === null || _err$response$data === void 0 ? void 0 : _err$response$data.message) !== null && _err$response$data$me !== void 0 ? _err$response$data$me : err.message;
};

const onError = async (err, req, res, next) => {
  res.status(500).send({
    message: err.toString()
  });
};



/***/ }),

/***/ 8054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ calculateOfferPrice)
/* harmony export */ });
function calculateOfferPrice(originalPrice, offerPercentage) {
  const newPrice = originalPrice - originalPrice * (offerPercentage / 100);
  return Math.ceil(newPrice);
}

/***/ }),

/***/ 874:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 2737:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Dashboard");

/***/ }),

/***/ 1041:
/***/ ((module) => {

module.exports = require("@mui/icons-material/HelpCenter");

/***/ }),

/***/ 1090:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 9613:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 586:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Login");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 4734:
/***/ ((module) => {

module.exports = require("@mui/icons-material/School");

/***/ }),

/***/ 1893:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 3801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 7949:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 4459:
/***/ ((module) => {

module.exports = require("@mui/material/Rating");

/***/ }),

/***/ 8035:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 5619:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3308:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3061,2236,6420,3391,3296,7733,3291], () => (__webpack_exec__(4605)));
module.exports = __webpack_exports__;

})();